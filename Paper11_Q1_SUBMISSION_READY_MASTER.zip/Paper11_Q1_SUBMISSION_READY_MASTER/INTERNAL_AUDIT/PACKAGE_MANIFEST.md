# Paper 11 Research Package Manifest

**Title:** Invariance of the Guyer--Krumhansl Fourier-Resonance Sensitivity Singularity to Boundary Heat Loss in Laser Flash Testing  
**Lead Author:** Dr. Vipin Gupta (*Department of Mathematics, Gurugram University, India*)  
**Package Version:** v4.0 (Q1 SCI Edition, Corrected & Re-Verified)  
**Date:** September 2026  
**License:** Open-Access Research Archive (Creative Commons Attribution 4.0 / MIT for Code)

---

## 1. Directory Tree & Architecture

```
Paper11_Q1_Final/
├── audit/
│   ├── PACKAGE_MANIFEST.md               # This manifest
│   ├── final_audit_report.md             # 15-point adversarial audit, claim ledger, Gate decision
│   └── RED_FLAG_FIX_REPORT.md            # v4 corrective-action log (reference/data/documentation fixes)
├── blueprint/
│   └── research_blueprint.md             # Research blueprint, methodology, and CRLB theory
├── data/                                 # 18 authoritative CSV datasets (see Section 3)
├── derivations/
│   ├── derivations.md                    # Comprehensive mathematical derivations (Markdown)
│   ├── guyer_krumhansl_heatloss_derivation.tex  # LaTeX derivation document source
│   └── guyer_krumhansl_heatloss_derivation.pdf  # Compiled 9-page derivation deliverable
├── figures/                              # 10-figure publication suite (vector PDF + 300-DPI PNG)
├── literature/                           # 7 search/novelty audit documents + 5 CSV audit matrices
├── manuscript/
│   ├── main.tex                          # Q1 SCI manuscript source (LaTeX, elsarticle)
│   ├── references.bib                    # 64-entry DOI-verified BibTeX bibliography
│   ├── elsarticle.cls                    # Elsevier article class (bundled for offline compilation)
│   ├── elsarticle-num.bst                # Elsevier numerical bibliography style
│   ├── compile.sh                        # pdflatex → bibtex → pdflatex → pdflatex
│   ├── main.pdf                          # Compiled 44-page publication-ready PDF
│   └── figures/                          # Figure assets for manuscript compilation
├── overleaf/                             # Byte-identical Overleaf mirror of manuscript sources
├── program/                              # 10 Python modules (see program/README.md)
└── run_manifest.json                     # Machine-readable execution log (runtimes, environment, checks)
```

---

## 2. Master Reproducibility Instructions

### 2.1 Python Numerical Pipeline

```bash
# 1. Install prerequisites (Python >= 3.10)
cd Paper11_Q1_Final/program
pip install -r requirements.txt

# 2. Execute master end-to-end reproducibility runner
python3 reproduce_all.py
```

Measured execution time is approximately **10 minutes** on a standard multicore CPU (see `run_manifest.json` for the per-stage breakdown of the reference run). The runner regenerates all 18 data artifacts in `data/`, regenerates all 10 figures (PDF + 300-DPI PNG) in `figures/`, `manuscript/figures/` and `overleaf/figures/`, and writes execution timestamps and environment versions to `run_manifest.json`. Verified reproducibility (September 2026): all CSV datasets reproduce bit-for-bit except timing columns; all figures reproduce byte-for-byte except PDF creation timestamps.

### 2.2 LaTeX Manuscript Compilation

```bash
cd Paper11_Q1_Final/manuscript
chmod +x compile.sh
./compile.sh
```

Runs `pdflatex` → `bibtex` → `pdflatex` → `pdflatex`, producing `main.pdf` (44 pages, zero errors, zero undefined citations or references). `elsarticle.cls` and `elsarticle-num.bst` are bundled so the document compiles offline.

### 2.3 Mathematical Derivations Companion Compilation

```bash
cd Paper11_Q1_Final/derivations
pdflatex -interaction=nonstopmode guyer_krumhansl_heatloss_derivation.tex
pdflatex -interaction=nonstopmode guyer_krumhansl_heatloss_derivation.tex
```

Produces `guyer_krumhansl_heatloss_derivation.pdf` (9 pages).

### 2.4 Overleaf Deployment

Upload the contents of `overleaf/` (main.tex, references.bib, elsarticle.cls, elsarticle-num.bst, figures/) as a new Overleaf project and click **Recompile** (pdfLaTeX). No internet access or manual file linking is required.

---

## 3. Inventory of Generated Datasets (18 Artifacts)

| Dataset File | Description | Rows |
|:---|:---|:---:|
| `validation_laplace.csv` | PDE vs analytical de Hoog Laplace inversion across $Bi \in [0, 0.5]$ | 8 |
| `validation_cowan.csv` | PDE vs exact Cowan Fourier series (50 roots) across $Bi \in [0.01, 0.5]$ | 5 |
| `asymptotic_fourier_convergence.csv` | Asymptotic Fourier convergence as $\tau_q, \kappa^2 \to 0$ | 7 decades |
| `mesh_convergence.csv` | Spatial grid refinement study ($N_x \in \{100, 200, 400, 800\}$) | 4 resolutions |
| `dehoog_convergence.csv` | Laplace inversion precision (dps 30–80) and degree ($M \in \{20,30,40,60\}$) | 16 evaluations |
| `heatloss_parameter_sweep.csv` | Sensitivity correlation $\rho$, condition numbers, and SVD across 12 Biot numbers | 12 |
| `sensitivity_profiles.csv` | Time-resolved sensitivity trajectories $J_{\tau_q}(t), J_{\kappa^2}(t), J_{Bi}(t)$ | 100 time steps |
| `near_resonance_scaling.csv` | Near-resonance singular value canyon across $B \in [0.5, 1.5]$ (refined near $B=1$) | 102 |
| `off_resonance_sweep.csv` | Wide off-resonance singular value landscape | 51 |
| `scaling_summary.csv` | Mean scaling prefactors $C(Bi)$ and $\operatorname{cond}(F)$ prefactors | 6 |
| `scaling_regression_twosided.csv` | Two-sided regression audit: exponents, standard errors, $R^2$, linear prefactors | 2 branches |
| `crlb_configuration_audit.csv` | Multi-configuration CRLB threshold $|B-1|_{\mathrm{crit}}$ | 27 settings |
| `field_invariance_asymmetric.csv` | 50-digit continuous Laplace field residuals across space and asymmetric cooling | 15 evaluations |
| `interior_point_mesh_refinement.csv` | PDE interior-point mesh refinement residuals across $x \in \{0, 0.25, 0.5, 0.75, 1\}$ | 20 evaluations |
| `sensitivity_step_size_convergence.csv` | Finite-difference step truncation floor analysis ($h \in [10^{-2}, 10^{-16}]$) | 8 step sizes |
| `spatiotemporal_3d_temperature.csv` | 3D spatiotemporal temperature grid ($25 \times 30$) | 750 |
| `spatiotemporal_3d_sensitivities.csv` | 3D spatiotemporal sensitivity grid from analytic differentiation ($20 \times 25$) | 500 |
| `canyon_3d_landscape.csv` | 3D Singularity Canyon condition-number landscape ($(B, Bi)$ grid) | 189 |

---

## 4. Reference Integrity

All 64 bibliography entries in `manuscript/references.bib` (61 cited in the text plus 3 supporting citations added in v4) were re-verified against the Crossref metadata API in September 2026. Four DOIs that resolved to unrelated articles were corrected, and two inaccurate titles were fixed:

| Key | Correction |
|:---|:---|
| `cowan1963pulse` | DOI `10.1063/1.1729335` → `10.1063/1.1729564` (previous DOI resolved to an unrelated ruby-laser paper) |
| `both2016deviation` | DOI `10.1515/jnet-2015-0038` → `10.1515/jnet-2015-0035` |
| `kovacs2018analytic` | DOI `10.1016/j.ijheatmasstransfer.2018.07.039` → `10.1016/j.ijheatmasstransfer.2018.06.082`; title aligned with the published version |
| `dowding1995estimation` | DOI `10.2514/3.670` → `10.2514/3.666` |
| `guyer1966solution` | Title corrected to the published "Solution of the Linearized Phonon Boltzmann Equation" |
| `li2020appropriate` | Volume corrected 150 → 148 |

The same corrections were propagated to `literature/literature_matrix.csv`, `literature/literature_claim_matrix.csv`, and `literature/reference_verification_master.csv`.

---

## 5. Final Gate Certification Summary

| Gate Criteria | Status | Scientific Assessment |
|:---|:---:|:---|
| **Gate A: Mathematical Soundness** | **PASS** | Complete analytical derivation from the coupled PDE system; closed-form Laplace transfer functions; holomorphic modal completeness in the physical half-plane $\operatorname{Re}(s) > 0$; exact sensitivity collinearity; consistent noise-weighted Fisher Information formulation. |
| **Gate B: Novelty & Literature** | **PASS** | Rigorously positioned relative to Kovács (2018), Ramos et al. (2023), ASTM E1461-13(2022), and Cowan (1963); establishes the exact invariance of the Guyer--Krumhansl Fourier-resonance singularity to linear Robin boundary heat loss. All 64 references DOI-verified against Crossref. |
| **Gate C: Numerical Rigor** | **PASS** | Tri-tier verification (Laplace inversion, exact Fourier series, conservative FVM); exact second-order grid convergence ($p = 2.00$); 50-digit continuous Laplace field verification; analytic-derivative sensitivity fields with exactly zero collinearity defect; independent two-sided regression scaling archived to CSV; multi-configuration CRLB bounds. |
| **Gate D: Package Completeness** | **PASS** | Automated master runner `reproduce_all.py` (~10 min, verified to regenerate every artifact); verified `run_manifest.json`; 18 CSV datasets; 10 publication figures (vector PDF + 300-DPI PNG); 44-page primary manuscript PDF with all citations resolved; 9-page derivation companion PDF; complete Overleaf mirror; Q1 front-matter statements (CRediT, funding, data availability). |

**FINAL RECOMMENDATION: Gate A–D (PASS) — Prepared for direct submission to Q1 SCI thermal-science journals.**
