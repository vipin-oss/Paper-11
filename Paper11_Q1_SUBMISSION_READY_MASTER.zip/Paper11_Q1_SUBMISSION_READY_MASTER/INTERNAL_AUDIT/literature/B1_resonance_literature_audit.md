# Adversarial Literature Audit: The "B=1" Resonance Literature

**Document ID:** LIT-AUDIT-B1-01  
**Scope:** Rigorous examination of prior art addressing the Fourier-resonance parameter ratio $B \equiv \tau_T / \tau_q = \kappa^2 / (\alpha_0 \tau_q) = 1$.  
**Purpose:** Ensure precise scientific differentiation between PDE reduction, forward solution collapse, sensitivity collinearity, and structural identifiability failure.

---

## 1. Conceptual Framework: Four Distinct Levels of Resonance Claims

In hostile peer review, conflating forward model equivalence with inverse identifiability failure is a fatal flaw. This audit establishes four mathematically distinct levels of claims regarding $B=1$:

| Level | Mathematical Concept | Definition / Criterion | Physical & Mathematical Implication |
|:---:|:---|:---|:---|
| **Level 1** | **Reduced Governing PDE** | Substitution into the bulk constitutive law causes higher-order derivative operators to cancel out: $\mathcal{L}_{\mathrm{GK}}[T] \to \mathcal{L}_{\mathrm{Fourier}}[T]$. | The bulk field equation becomes formally identical to the parabolic diffusion equation. Does *not* automatically guarantee that boundary conditions or transient boundary terms preserve this equivalence. |
| **Level 2** | **Fourier-Equivalent Forward Model** | The complete initial-boundary-value problem (IBVP) produces a temperature solution identical to the Fourier solution: $\theta(x, t) \equiv \theta_{\mathrm{Fourier}}(x, t)$ for specified boundary conditions. | Forward forward predictions match Fourier data exactly. Established by Kovács (2018) for *adiabatic* boundaries ($Bi = 0$); unproven prior to Paper 11 for general Robin boundaries ($Bi > 0$). |
| **Level 3** | **Sensitivity Collapse / Collinearity** | The parameter gradient vectors become linearly dependent: $\partial \theta / \partial \tau_q = -\alpha_0 \partial \theta / \partial \kappa^2$ across the observation domain. | The sensitivity Jacobian $\bm{J}$ suffers a loss of column rank ($\operatorname{rank}(\bm{J}) < p$). |
| **Level 4** | **Structural Identifiability Failure** | The Fisher Information Matrix $\bm{F} = \frac{1}{\sigma_n^2}\bm{J}^\top \bm{J}$ has an exact zero eigenvalue ($\det(\bm{F}) = 0$), inducing an infinite Cramér--Rao Lower Bound along the null direction $(1, \alpha_0, 0)^\top$. | No measurement algorithm, filtering technique, or noise reduction can uniquely resolve $\tau_q$ and $\kappa^2$ simultaneously from temperature data alone. |

---

## 2. Study-by-Study Detailed Audit

### 2.1 Tzou (1995a, 1997) — Dual-Phase-Lag Model
- **Model:** Dual-Phase-Lag (DPL): $\bm{q}(\bm{r}, t + \tau_q) \approx \bm{q} + \tau_q \frac{\partial \bm{q}}{\partial t} = -\lambda_0 \nabla T - \lambda_0 \tau_T \frac{\partial \nabla T}{\partial t}$.
- **Definition of Ratio:** $B \equiv \tau_T / \tau_q$. In 1D planar geometry without internal heat sources, DPL and GK share the identical bulk PDE structure with $\tau_T \equiv \kappa^2 / \alpha_0$.
- **Equivalence Type:** **Level 1 (PDE reduction)**. Tzou noted that when $\tau_q = \tau_T$, the mixed time-derivative terms cancel out:
  $$\tau_q \frac{\partial^2 T}{\partial t^2} + \frac{\partial T}{\partial t} = \alpha_0 \frac{\partial^2 T}{\partial x^2} + \alpha_0 \tau_T \frac{\partial^3 T}{\partial x^2 \partial t} \quad \xrightarrow{\tau_q = \tau_T} \quad \frac{\partial T}{\partial t} = \alpha_0 \frac{\partial^2 T}{\partial x^2}.$$
- **Boundary Conditions Examined:** Semi-infinite media, specified surface temperatures (Dirichlet), or specified heat fluxes (Neumann).
- **Robin Boundary Loss Involved?** **No.**
- **Laser Flash Pulse Involved?** **No.**
- **Sensitivity Collinearity Proven?** **No.** Tzou focused exclusively on forward wave propagation, thermal shock waves, and damping regimes ($B < 1$ vs $B > 1$).
- **FIM / SVD / Inverse Identifiability?** **No.** Inverse problems, Fisher information, and parameter estimation were not examined.

### 2.2 Wang, Xu, and Zhou (2001, 2002) — Thermal Resonance in DPL
- **Model:** Dual-Phase-Lag (DPL).
- **Definition of Ratio:** $B \equiv \tau_T / \tau_q$.
- **Equivalence Type:** **Level 1 (PDE reduction) and Forward Wave Extinction**.
- **Key Findings:** Under harmonically oscillating surface heat flux or temperature, the wave reflections interfere destructively at $B = 1$. The phase speed approaches infinity, wave fronts disappear, and the thermal response transitions to pure diffusive oscillation.
- **Robin Boundary Loss Involved?** **No.** Examined periodic sinusoidal excitation in semi-infinite and finite slabs with insulated or fixed-temperature boundaries.
- **Laser Flash Pulse Involved?** **No.**
- **Sensitivity Collinearity Proven?** **No.**
- **FIM / SVD / Inverse Identifiability?** **No.** Wang & Xu were concerned with thermal resonance phenomena and wave damping, not parameter estimation.

### 2.3 Ordonez-Miranda and Alvarado-Gil (2010) — Photothermal DPL Parameter Estimation
- **Model:** Dual-Phase-Lag (DPL) with thermal interface resistance.
- **Definition of Ratio:** $B \equiv \tau_T / \tau_q$.
- **Equivalence Type:** **Level 3 (Partial / Qualitative Sensitivity Drop)**.
- **Key Findings:** Investigated the sensitivity of surface temperature and phase lag to time delays $\tau_q$ and $\tau_T$ under modulated photothermal heating. Noted that when $\tau_q \approx \tau_T$, the phase lag of the surface temperature becomes insensitive to the individual values of $\tau_q$ and $\tau_T$, leading to large parameter estimation uncertainties.
- **Robin Boundary Loss Involved?** **No.** Included contact resistance at internal interfaces, but not convective-radiative environmental cooling tails.
- **Laser Flash Pulse Involved?** **No.** Modulated frequency-domain photothermal excitation (photoacoustic / photothermal radiometry), not time-domain pulsed laser flash.
- **Exact Collinearity Analytically Proven?** **No.** Observed numerical sensitivity decay graphically; did not prove an analytical linear dependence relation between sensitivity vectors.
- **FIM / SVD / Near-Resonance Scaling?** **No.** Did not construct the Fisher Information Matrix, did not perform SVD, did not derive near-resonance power-law scaling $\sigma_{\min} \propto |B-1|$.

### 2.4 Kovács (2018) — Analytic Laser Flash Solution for Guyer--Krumhansl
- **Model:** Guyer--Krumhansl (GK): $\tau_q \partial_t q + q + \lambda_0 \partial_x T - \kappa^2 \partial_x^2 q = 0$.
- **Definition of Ratio:** Examined the specific parameter setting $\kappa^2 = \tau_q$ in non-dimensional units (corresponding to $B = \kappa^2 / (\alpha_0 \tau_q) = 1$).
- **Equivalence Type:** **Level 2 (Forward Solution Collapse) and Level 3 (Adiabatic Sensitivity Collinearity)**.
- **Key Findings:** Solved the 1D GK laser flash problem analytically in the Laplace domain for **ideal adiabatic boundaries** ($Bi = 0$). Demonstrated that when $\kappa^2 = \tau_q$, the rear-face temperature rise $\theta(1, t)$ reduces identically to the classical Parker (1961) Fourier solution. Deduced that on the rear face under adiabatic conditions, the sensitivity derivatives satisfy $\partial \theta / \partial \tau_q = -\partial \theta / \partial \kappa^2$.
- **Robin Boundary Loss Involved?** **No.** The entire formulation in Kovács (2018) enforces strict adiabatic boundary conditions: $q(0, t) = q_{\mathrm{laser}}(t)$, $q(L, t) = 0$.
- **Full-Field Invariance ($x \in [0, 1]$)?** Not explicitly proved for Robin boundaries.
- **FIM / SVD / CRLB Analysis?** **No.** Kovács noted the rear-face sensitivity cancellation but did not construct the Fisher Information Matrix, did not analyze noise covariance, did not perform SVD, and did not compute Cramér--Rao Lower Bounds.
- **Near-Resonance Scaling?** **No.** Did not investigate the neighborhood $|B-1| > 0$ or determine the singular-value scaling canyon.

---

## 3. Synthesis: Exact Novelty Demarcation of Paper 11

Prior to the present study, the literature contained:
1. **Bulk PDE equivalence** for DPL models under unbounded or isolated conditions (Tzou 1995; Wang & Xu 2002);
2. **Qualitative sensitivity reduction** under frequency-modulated photothermal excitation (Ordonez-Miranda & Alvarado-Gil 2010);
3. **Rear-face forward solution collapse** under strictly **adiabatic** laser flash testing ($Bi = 0$) (Kovács 2018).

**What Paper 11 Uniquely Establishes:**
1. **Coupled Robin Boundary Value Formulation:** Formulates the complete 1D Guyer--Krumhansl laser flash problem with asymmetric front and rear convective-radiative Robin boundary conditions ($Bi_0, Bi_L > 0$) and proves modal completeness in the physical right-half plane $\operatorname{Re}(s) > 0$.
2. **Full-Field Invariance Theorem (Theorem 1):** Proves analytically that at $B = 1$, the GK solution collapses to the Fourier solution **identically across all space $x \in [0, 1]$, all times $t \ge 0$, and all Biot numbers $Bi_0, Bi_L \ge 0$**, establishing that boundary dissipation cannot break the forward degeneracy.
3. **Exact Sensitivity Collinearity (Theorem 2):** Proves via the multivariate chain rule that $\bm{J}_{\tau_q}(x, t) \equiv -\alpha_0 \bm{J}_{\kappa^2}(x, t)$ holds universally across the entire spatial domain for arbitrary Robin cooling.
4. **Structural Fisher Information Null Vector:** Constructs the 3-parameter Fisher Information Matrix $(\tau_q, \kappa^2, Bi)$ and proves that Robin cooling contributes strictly zero projection along the null direction $(1, \alpha_0, 0)^\top$ ($\sigma_3 \equiv 0$, condition number $\kappa = \infty$).
5. **Near-Resonance Perturbation Theory (Theorem 3):** Derives from asymptotic expansions of the complex wavenumber and boundary impedance that the collinearity defect is strictly $\mathcal{O}(|B-1|)$, proving the linear singular-value canyon $\sigma_{\min} \approx C(Bi)|B-1|$.
6. **Multi-Configuration CRLB Audit:** Quantifies the critical experimental decoupling corridors $|B-1|_{\mathrm{crit}}$ across 27 distinct noise, sampling, and sensor configurations.

**Scientific Conclusion:**  
Paper 11 does not claim to have discovered the bulk PDE reduction at $B=1$ (which traces to Tzou and Wang & Xu) nor the adiabatic rear-face flash equivalence (which traces to Kovács). Paper 11 discovers and proves that **finite Robin boundary heat loss is structurally incapable of regularizing this singularity**, establishing the mathematical invariance, the exact full-field collinearity, the FIM null vector, and the quantitative near-resonance CRLB corridors.
