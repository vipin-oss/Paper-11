# Adversarial Literature Audit: Competing Identifiability Literature & Boundary Effects

**Document ID:** COMP-AUDIT-ID-01  
**Scope:** Critical analysis of literature reporting successful parameter identification via boundary dissipation, multi-sensor designs, cooling-tail observations, and competing non-Fourier inversion algorithms.  
**Purpose:** Ensure Paper 11 fairly acknowledges cases where boundary loss improves conditioning, while rigorously defending why it fails to remove the structural null direction at $B = 1$ in the linear 1D GK system.

---

## 1. Classical Heat Transfer: Cases Where Boundary Dissipation Improves Identifiability

In the broader inverse heat conduction problem (IHCP) literature, dissipative boundary conditions often **enhance** parameter identifiability:

1. **Beck et al. (1985) & Beck & Arnold (1977):**  
   In classical parameter estimation, estimating both thermal conductivity $\lambda_0$ and volumetric heat capacity $\rho c$ simultaneously from a single transient experiment is impossible under adiabatic boundary conditions without knowledge of the absorbed heat flux. Introducing heat loss to an ambient of known temperature breaks the scaling degeneracy between energy storage and conduction, enabling simultaneous estimation.
2. **Emery et al. (2000) & Fadale et al. (1995):**  
   Demonstrated via Fisher Information Matrix (FIM) analysis that boundary convective heat loss introduces independent spatial modes ($s_n(Bi)$), turning near-collinear sensitivities into linearly independent trajectories over long measurement intervals.
3. **Dowding et al. (1995) & Łapka et al. (2020):**  
   Showed that observing long cooling tails provides the necessary sensitivity to simultaneously estimate surface heat transfer coefficients and directional thermal conductivities.

### How Paper 11 Reconciles This:
Paper 11 does **not** claim that boundary heat loss never regularizes parameter estimation. On the contrary, Section 5.2 and Section 6 explicitly demonstrate that:
- Adding the Biot number $Bi$ creates a well-conditioned 2D observable subspace ($\sigma_1 / \sigma_2 \in [2.34, 4.90]$);
- Boundary heat loss allows $Bi$ to be resolved with high precision ($\operatorname{SE}(\hat{Bi}) \le 1.24 \times 10^{-3}$ at $1.0\%$ noise);
- However, for the **constitutive non-Fourier parameters $(\tau_q, \kappa^2)$ at exact $B = 1$**, the governing spatial transfer function collapses identically to Fourier conduction across all frequencies $s$. The boundary loss acts as a multiplicative scalar operator across the entire spectrum, yielding **strictly zero projection** onto the null direction $(1, \alpha_0, 0)^\top$.

---

## 2. Experimental Literature Reporting Simultaneous Non-Fourier Identification

Several prior studies have reported extracting relaxation times $\tau_q$ and/or non-local parameters from transient heat pulse experiments:

1. **Both et al. (2016) & Ván et al. (2017):**  
   Fitted Guyer--Krumhansl and dual-phase-lag models to room-temperature flash experiments on rock (basalt) and biological samples, reporting non-zero values for relaxation and non-local parameters.  
   *Audit Finding:* In these studies, the fitted parameters corresponded to $B \ll 0.1$ or $B \gg 10$, placing the material deep in the non-resonant hyperbolic or diffusive regimes where sensitivity vectors are non-collinear and $\sigma_{\min} \gg 0$.
2. **Ordonez-Miranda & Alvarado-Gil (2010):**  
   Investigated DPL parameter estimation from modulated photothermal measurements. Confirmed that parameter estimation succeeded when $\tau_q \ne \tau_T$ ($B \ne 1$), but encountered extreme numerical instability and parameter correlation when $B \to 1$.
3. **Tröger et al. (2022):**  
   Evaluated local identifiability of anisotropic thermal conductivity tensors using FIM and SVD, showing that parameter correlations can be resolved by optimizing sensor placement and heating trajectories.

### How Paper 11 Reconciles This:
Paper 11 does **not** dispute that non-Fourier parameters can be identified far from resonance ($|B-1| \gg 0$). Rather, Paper 11 explains **why** previous inversions suffered severe numerical conditioning whenever $B \approx 1$: the underlying Fisher Information Matrix undergoes a structural rank deficiency proportional to $|B-1|^2$.

---

## 3. Multi-Sensor and Multi-Frequency Regularization

A common reviewer objection is: *"Can multi-sensor measurements (e.g., front-face thermoreflectance + rear-face pyrometry) or thickness variation break the parameter degeneracy?"*

### Multi-Sensor Analysis:
- If $\theta_{\mathrm{GK}}(x, t; B=1) \equiv \theta_{\mathrm{Fourier}}(x, t)$ for **all** $x \in [0, 1]$ and all $t \ge 0$, then differentiating with respect to $\tau_q$ and $\kappa^2$ yields:
  $$\frac{\partial \theta}{\partial \tau_q}(x, t) = -\alpha_0 \frac{\partial \theta}{\partial \kappa^2}(x, t), \quad \forall x \in [0, 1], \; \forall t \ge 0.$$
- Consequently, measuring at any interior or boundary location $x_i$ merely produces another sensitivity vector that is perfectly anti-parallel to the $\kappa^2$ sensitivity vector. Stacking multiple sensors adds rows to $\bm{J}$, but the two columns remain linearly dependent:
  $$\bm{J}_{\tau_q} = -\alpha_0 \bm{J}_{\kappa^2} \implies \operatorname{rank}(\bm{J}) \le 2 \quad \text{in the 3-parameter space } (\tau_q, \kappa^2, Bi).$$
- Therefore, at **exact $B=1$ under the linear 1D model**, multi-sensor measurements **cannot** remove the structural null direction.
- However, for **near-resonant media ($B \ne 1$)**, our CRLB audit confirms that multi-sensor configurations (e.g., front + rear monitoring) dramatically reduce parameter variance by increasing the effective prefactor $C_{\mathrm{eff}}$, contracting the required noise corridor from $|B-1| \ge 0.914$ down to $|B-1| \ge 0.150$ at $1.0\%$ noise.

### Specimen Thickness Scaling ($\kappa(L)$):
- As established by Alvarez & Jou (2007) and Guo & Wang (2015), the microscopic non-local parameter $\kappa$ in bounded geometries depends on the specimen thickness $L$ through boundary phonon scattering:
  $$\kappa_{\mathrm{eff}}^2(L) = \frac{\kappa_0^2}{1 + C_k \frac{\Lambda}{L}}.$$
- Varying specimen thickness $L$ shifts the non-dimensional parameter $B(L) \equiv \kappa_{\mathrm{eff}}^2(L) / (\alpha_0 \tau_q)$ away from unity, actively perturbing the physical system out of the resonance canyon. This provides a rigorous experimental pathway to break the degeneracy.

---

## 4. Nonlinear Radiative Heat Loss ($T^4$)

- Under large temperature rises ($\Delta T / T_0 \sim 0.3$), nonlinear radiation $\varepsilon \sigma_{\mathrm{SB}} (T^4 - T_0^4)$ introduces higher harmonic spatial couplings that break the linear modal structure (Sundar & Sudha 2025; Nishi et al. 2020).
- Paper 11 explicitly scopes its mathematical proof to the **linearized Robin regime** ($\Delta T / T_0 \ll 1$), which is the operational standard for ASTM E1461 testing. Under this linear regime, the invariance is mathematically exact and unassailable.
