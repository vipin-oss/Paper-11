# Comprehensive Literature Search Strategy & Protocol
**Manuscript:** Invariance of the Guyer–Krumhansl Fourier-Resonance Sensitivity Singularity to Boundary Heat Loss in Laser Flash Testing  
**Author:** Dr. Vipin Gupta (*Department of Mathematics, Gurugram University, India*)  
**Target:** Q1 SCI Heat Transfer & Applied Mathematics Journals (IJHMT, AMM, IJTS)  
**Date:** September 2026  

---

## 1. Scope and Search Objectives

The primary objective of this literature overhaul is to establish a rigorous, scholarly foundation for Paper 11 across eight core domains:
1. **Laser Flash Metrology & Standards:** ASTM E1461, thermal diffusivity characterization, foundational flash theory, modern high-temperature implementations.
2. **Boundary Heat Loss & Finite-Pulse Corrections:** Analytical and numerical models for convective/radiative cooling tails, finite Biot numbers, asymmetric front/rear boundary heat loss, and historical correction procedures.
3. **Non-Fourier Conduction & Phonon Hydrodynamics:** Cattaneo–Vernotte hyperbolic transport, Guyer–Krumhansl equations, phonon hydrodynamics, second sound observations, and thermodynamic foundations.
4. **Guyer–Krumhansl Laser Flash Applications:** Analytical, numerical, and experimental pulse-heating studies incorporating Guyer–Krumhansl transport.
5. **Nonlocal & Size-Dependent Transport:** Phonon mean free path effects, boundary scattering in thin films/nanolayers, size-dependent effective conductivity, and geometric vs. constitutive scaling.
6. **Inverse Heat Conduction & Parameter Estimation:** Sensitivity coefficients, parameter correlations, ill-posed inverse problems, and classical regularization techniques.
7. **Fisher Information Matrix, SVD & Identifiability:** Structural vs. practical identifiability, Cramér–Rao Lower Bounds (CRLB), singular value decomposition of sensitivity matrices, and optimal experimental design.
8. **Fourier Resonance & Parameter Collinearity:** Structural parameter degeneracy, dual-phase-lagging equivalence, sensitivity canyons, and condition number divergence.

---

## 2. Bibliographic Database Query Formulations

Searches were conducted systematically across major academic databases and publisher platforms:
- **Elsevier ScienceDirect** (*International Journal of Heat and Mass Transfer*, *Applied Mathematical Modelling*, *International Journal of Thermal Sciences*, *Physics Reports*)
- **SpringerLink** (*International Journal of Thermophysics*, *Continuum Mechanics and Thermodynamics*, *Zeitschrift für angewandte Mathematik und Physik*)
- **American Physical Society (APS)** (*Physical Review*, *Physical Review Letters*, *Physical Review B*)
- **American Institute of Physics (AIP)** (*Journal of Applied Physics*, *Applied Physics Letters*, *Applied Physics Reviews*)
- **American Society of Mechanical Engineers (ASME)** (*Journal of Heat Transfer*)
- **Institute of Physics (IOP) / Science / Nature Portfolio** (*Science*, *Nature Communications*, *Measurement Science and Technology*)
- **ASTM Compass / Standards Portal** (*ASTM E1461-13(2022)*)
- **Crossref Metadata API** (Independent verification of DOIs, publication years, titles, and volume/page details)

### Specific Search Strings Used:
- `("laser flash" OR "flash method") AND ("thermal diffusivity" OR "heat loss") AND ("Cowan" OR "Cape-Lehman" OR "ASTM E1461")`
- `("Guyer-Krumhansl" OR "phonon hydrodynamics") AND ("laser flash" OR "heat pulse" OR "second sound")`
- `("inverse heat conduction" OR "parameter estimation") AND ("Fisher information" OR "identifiability" OR "Cramer-Rao")`
- `("dual-phase-lag" OR "Guyer-Krumhansl") AND ("resonance" OR "collinearity" OR "sensitivity analysis")`
- `("second sound" OR "phonon hydrodynamics") AND ("graphite" OR "nanolayers") AND ("2019".."2026")`

---

## 3. Inclusion and Exclusion Criteria

### Inclusion Criteria:
1. Peer-reviewed journal articles, authoritative books, or official metrological standards.
2. Direct mathematical, physical, or experimental relevance to laser flash analysis, non-Fourier conduction, boundary heat loss, inverse problems, or identifiability analysis.
3. Verified DOIs or standard publisher metadata matching Crossref database records.
4. Balanced distribution: seminal foundational papers, established classic corrections, and modern 2018–2026 state-of-the-art advances.

### Exclusion Criteria:
1. Unverifiable citations, preprint duplicates with published counterparts, or predatory publisher outlets.
2. Superficial citation padding without specific contextual relevance to the sentence or paragraph.
3. Fabricated or hallucinated references.
4. Mismatched or non-resolving DOIs.

---

## 4. Verification Protocol

Every candidate citation was audited programmatically using Crossref's public REST API (`api.crossref.org`) to confirm:
- Registered DOI string matches the article.
- Author list matches primary journal records.
- Article title and publication year are exact.
- Journal name and volume/page numbers conform to standard BibTeX styling.

Results of this audit are cataloged in `literature_matrix.csv`.
