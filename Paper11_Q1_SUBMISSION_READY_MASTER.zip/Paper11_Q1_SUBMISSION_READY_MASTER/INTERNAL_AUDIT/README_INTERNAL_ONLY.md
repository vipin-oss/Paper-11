# INTERNAL_AUDIT — internal quality-assurance records

**This directory is not part of the reviewer-facing package.** It contains the internal
review, audit and literature-search records produced while preparing the manuscript.

Nothing in `manuscript/`, `supplementary/`, `program/`, `data/`, `figures/`, `overleaf/`,
`derivations/`, `README.md`, `REPRODUCIBILITY.md` or `CHANGELOG_FINAL_REPAIR.md` cites,
quotes, or depends on any file in this directory. The scientific content of the manuscript
and supplementary material is fully self-contained without it.

Contents:

| Path | Content |
| --- | --- |
| `PACKAGE_MANIFEST.md` | Artifact catalog and verification records for the delivered package |
| `final_audit_report.md` | Adversarial self-audit of the manuscript and package |
| `RED_FLAG_FIX_REPORT.md` | Log of corrective actions (references, data, documentation) |
| `research_blueprint.md` | Research blueprint and mathematical scaffolding |
| `literature/` | Search strategy, novelty audits, claim-to-reference matrices, per-reference verification ledger |

The reviewer-facing record of what changed during the final repair pass, including every
old and new scientific value, is `../CHANGELOG_FINAL_REPAIR.md`.
