# Research Blueprint: Invariance of Guyer--Krumhansl Fourier-Resonance Sensitivity Singularity to Boundary Heat Loss

**Author:** Dr. Vipin Gupta  
**Affiliation:** Department of Mathematics, Gurugram University, Gurugram, Haryana 122018, India  
**Target Journals:** *International Journal of Heat and Mass Transfer* / *Applied Mathematical Modelling* / *International Journal of Thermal Sciences*  
**Scope:** Q1 SCI Journal Article & Complete Reproducible Research Package  

---

## 1. Problem Statement & Research Motivation

### 1.1 Context
Laser flash analysis (ASTM E1461-13(2022)) is the standard experimental metrology for measuring the thermal diffusivity and conductivity of solid materials. In micro- and nanoscale devices, heterogeneous media, and non-equilibrium regimes, heat transport departs from Fourier diffusion. The Guyer--Krumhansl (GK) equation:
$$\tau_q \frac{\partial \bm{q}}{\partial t} + \bm{q} + \lambda_0 \nabla T - \kappa^2 \nabla^2 \bm{q} = \bm{0}$$
incorporates both temporal relaxation ($\tau_q$) and spatial non-locality ($\kappa^2 = \ell^2$).

### 1.2 The Fourier-Resonance Singularity
In one-dimensional planar heat conduction, when parameters satisfy the algebraic condition:
$$B \equiv \frac{\kappa^2}{\alpha_0 \tau_q} = 1,$$
where $\alpha_0 = \lambda_0 / (\rho c)$, the bulk partial differential equation mathematically reduces to the classical Fourier heat conduction equation. Under idealized adiabatic boundary conditions ($Bi = 0$), this produces an exact local sensitivity collinearity:
$$\bm{J}_{\tau_q}(t) = -\alpha_0 \bm{J}_{\kappa^2}(t).$$
Consequently, the sensitivity Jacobian loses column rank, the Fisher Information Matrix (FIM) becomes structurally singular, and simultaneous determination of $(\tau_q, \kappa^2)$ from transient temperature data is mathematically impossible.

### 1.3 The Research Question
In actual laboratory flash experiments, specimens invariably exchange heat with the surrounding environment via convection and radiation ($Bi_0, Bi_L > 0$), producing cooling tails.

**The Central Question:**  
*Does realistic Robin surface heat loss break the sensitivity collinearity and regularize the inverse problem? Or is the Fourier-resonance degeneracy an intrinsic bulk invariant that persists despite boundary cooling?*

---

## 2. Theoretical Architecture & Mathematical Framework

### 2.1 Coupled 1D Boundary-Value Problem
The dimensionless 1D Guyer--Krumhansl system in a finite slab $x \in [0, 1]$ is:
$$\tau_\Delta \frac{\partial \theta}{\partial t} + \frac{\partial q}{\partial x} = 0,$$
$$\tau_q \frac{\partial q}{\partial t} + q + \tau_\Delta \frac{\partial \theta}{\partial x} - \kappa^2 \frac{\partial^2 q}{\partial x^2} = 0,$$
subject to Robin boundary conditions:
$$q(0, t) = q_{\mathrm{pulse}}(t) - \tau_\Delta Bi_0 \theta(0, t),$$
$$q(1, t) = \tau_\Delta Bi_L \theta(1, t),$$
and quiescent initial conditions $\theta(x, 0) = 0, q(x, 0) = 0$.

### 2.2 Proof Strategy
1. **Modal Completeness:** In the Laplace domain, eliminate $q$ to obtain $\theta'' - m^2(s)\theta = 0$. Integrating $q' = -\tau_\Delta s \theta$ yields an integration constant $C_3(s)$. Substituting back into the constitutive equation forces $(1 + \tau_q s)C_3(s) \equiv 0$. In the physical domain of convergence $\mathbb{H}_0 \equiv \{s \in \mathbb{C} : \operatorname{Re}(s) > 0\}$, $\operatorname{Re}(1 + \tau_q s) > 1 > 0$, forcing $C_3(s) \equiv 0$ strictly. The system is mathematically closed with strictly two degrees of freedom.
2. **Dynamic Surface Impedance:** The boundary heat flux relates to the temperature gradient via $\bar{q} = -\tau_\Delta \mu(s) \theta'$, where $\mu(s) = \frac{1 + \kappa^2 s}{1 + \tau_q s}$.
3. **Simultaneous Collapse at $B = 1$:** When $\kappa^2 = \tau_q$ ($B = 1$):
   - Bulk propagation factor: $m(s) \equiv \sqrt{s}$.
   - Surface mobility: $\mu(s) \equiv 1 \implies \lambda_{\mathrm{eff}}(s) \equiv \lambda_0$.
   - Product: $m(s)\mu(s) \equiv \sqrt{s}$.
   - Characteristic denominator: $\Delta(s) \equiv \Delta_{\mathrm{Fourier}}(s)$.
   - Temperature field: $\bar{\theta}_{\mathrm{GK}}(x, s)|_{B=1} \equiv \bar{\theta}_{\mathrm{Fourier}}(x, s; Bi_0, Bi_L)$ for all $x \in [0, 1], s \in \mathbb{C}$.
4. **Multivariate Chain-Rule Sensitivity:** Differentiating $\bar{\theta}$ via intermediate variables $u=m(s), v=m\mu$ proves $\bm{J}_{\tau_q}(t) \equiv -\alpha_0 \bm{J}_{\kappa^2}(t)$ for all $Bi_0, Bi_L \ge 0$.
5. **Noise-Weighted FIM & SVD Subspace Decomposition:** Under discrete measurement noise $\bm{\epsilon} \sim \mathcal{N}(\bm{0}, \sigma_n^2 \bm{I})$, $\bm{F} = \frac{1}{\sigma_n^2}\bm{J}^\top \bm{J}$ has structural null vector $\bm{v}_{\mathrm{null}} = (\alpha_0, 1, 0)^\top$ and structural rank 2.

---

## 3. Computational Methodology & Numerical Validation

### 3.1 Time-Domain Staggered-Grid PDE Engine
- Spatial discretization: Cell centers $x_{i+1/2}$ for $\theta$, cell interfaces $x_i$ for $q$.
- Boundary extrapolation: Second-order stencils $\theta(0) = \frac{3}{2}\theta_1 - \frac{1}{2}\theta_2$ and $\theta(1) = \frac{3}{2}\theta_N - \frac{1}{2}\theta_{N-1}$.
- Time integration: Stiff ODE integration via SciPy BDF solver (`rtol = 1e-10`, `atol = 1e-12`).

### 3.2 Tri-Tier Verification Architecture
1. **Independent Numerical Laplace Inversion Algorithms:** de Hoog et al. (1982) Padé quotient-difference algorithm vs. modified Talbot (1979) contour integration on the analytical transfer function.
2. **Independent Analytical Time-Domain Benchmark:** Cowan (1963) Fourier eigenfunction series with 50 transcendental roots computed via Brent's method. Zero spatial discretization, zero Laplace inversion.
3. **Independent Spatial Discretization Cross-Check:** Conservative Finite Volume Method (FVM) with cell-face flux balancing.

### 3.3 Spatial Refinement & Invariance Metrics
- Mesh convergence: $N_x \in \{100, 200, 400, 800\}$ achieves exact $O(\Delta x^2)$ convergence ($p = 2.00$).
- High-precision field evaluation: Inverted continuous Laplace fields at 50-digit precision without premature float casting, obtaining numerical residuals sitting at the series truncation floor ($\sim 10^{-27}$).
- Parameter sweeps: 12 Biot numbers swept ($Bi \in [0.001, 0.5]$), confirming $\rho = -1.0000000000$ and condition numbers pinned at the finite-difference singularity floor ($\sim 10^{17}$).

---

## 4. Near-Resonance Scaling & Metrological Implications

### 4.1 Asymptotic Scaling Law
In the near-resonance neighborhood $B \approx 1$, analytical Taylor expansion in $\delta = B - 1$ proves that the collinearity defect is strictly linear in $\delta$. Two-sided linear regressions confirm:
$$\sigma_{\min}(B) \approx C(Bi) |B - 1|^{1.0}, \qquad C(Bi) \in [1.38, 1.48],$$
$$\operatorname{cond}(F_{2\times 2}) \approx \frac{C'(Bi)}{|B - 1|^2}, \qquad C'(Bi) \in [8.7, 14.4].$$

### 4.2 Comprehensive CRLB Audit Table
Under the Cramér--Rao Lower Bound $\operatorname{Cov}(\hat{\bm{p}}) \ge \sigma_n^2 (\bm{J}^\top \bm{J})^{-1}$, achieving a 10% relative accuracy threshold ($\operatorname{SE}(\hat{\tau}_q) / \tau_{q,0} \le 0.10$) defines the critical corridor half-width $|B - 1|_{\mathrm{crit}}$:

| Sensor Configuration | Sampling $N_t$ | $\sigma_n = 0.1\%$ | $\sigma_n = 0.5\%$ | $\sigma_n = 1.0\%$ |
|:---|:---:|:---:|:---:|:---:|
| Rear-face only ($x = 1.0$) | 10 | 0.242 | 1.208 | 2.416 |
| Rear-face only ($x = 1.0$) | 50 | 0.091 | 0.457 | 0.914 |
| Rear-face only ($x = 1.0$) | 100 | 0.064 | 0.322 | 0.643 |
| Front + Rear ($x = 0, 1$) | 50 | 0.015 | 0.075 | 0.150 |
| Multi-location (5 stations) | 50 | 0.013 | 0.063 | 0.126 |

*Key Takeaway:* The earlier values $|B - 1|_{\mathrm{crit}} \approx 0.34$ and $3.4$ correspond strictly to a 10-point rear-face sampling evaluating the principal singular mode. With standard sampling ($N_t = 50$), the coordinate threshold narrows to $0.091$ (0.1% noise) and $0.914$ (1.0% noise), while dual-surface monitoring contracts it to $0.015$ (0.1% noise).

### 4.3 Practical Metrological Recommendations
1. **Insufficiency of Standard Corrections:** Cowan (1963) and Cape--Lehman (1963) heat loss corrections cannot resolve non-Fourier parameter indeterminacy when $B \approx 1$.
2. **Thickness Scaling:** For homogeneous bulk materials with constant properties, $B \equiv \kappa^2 / (\alpha_0 \tau_q)$ is scale-invariant. However, reducing thickness $L$ amplifies dimensionless sensitivity amplitudes, helping off-resonance specimens ($B \ne 1$) escape the noise corridor. In nanolayers with size-dependent scattering ($\kappa = \kappa(L)$), $B$ can be physically tuned.
3. **Regularization Pathways:** Parameter identification requires perturbing the bulk transport physics away from Fourier resonance via mild thermal non-linearities ($\lambda = \lambda(T)$) or joint multi-thickness inversions on off-resonance samples.

---

## 5. Research Package Architecture

The package is organized into modular directories:
- `manuscript/`: LaTeX source (`main.tex`), verified bibliography (`references.bib`), compilation script (`compile.sh`), and compiled 20-page PDF (`main.pdf`).
- `derivations/`: Complete LaTeX derivations document (`guyer_krumhansl_heatloss_derivation.tex`) and compiled 9-page PDF (`guyer_krumhansl_heatloss_derivation.pdf`).
- `program/`: Master reproducibility runner (`reproduce_all.py`), computational scripts, dependency specification (`requirements.txt`), and documentation (`README.md`).
- `data/`: All 12 validated CSV datasets.
- `figures/`: All 6 publication figures in vector PDF and 300-DPI PNG format.
- `audit/`: Scientific audit report (`final_audit_report.md`) and package manifest (`PACKAGE_MANIFEST.md`).
- `blueprint/`: This research blueprint (`research_blueprint.md`).
- `overleaf/`: Ready-to-upload ZIP mirror for Overleaf compilation (`overleaf_ready.zip`).
