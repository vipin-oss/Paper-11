# Red-Flag Corrective-Action Report

**Package:** `Paper11_Q1_Final.zip` (v4.0)  
**Subject:** Invariance of the Guyer–Krumhansl Fourier-Resonance Sensitivity Singularity to Boundary Heat Loss in Laser Flash Testing  
**Audit date:** September 2026  
**Scope:** Every quantitative value, reference, code artifact, and documentation claim in the v3.1 package was re-checked against (i) the shipped CSV datasets, (ii) the Crossref metadata API, (iii) an independent re-derivation of the mathematics, and (iv) a full re-run of the computational pipeline. Defects are listed below with the evidence and the applied fix.

---

## R1. Four bibliographic DOIs resolved to unrelated articles (Critical — Gate B)

All 64 entries of `manuscript/references.bib` were re-queried against the Crossref
metadata API (`api.crossref.org/works/{doi}`) and compared on title, journal, volume,
page range and year.

| Key | Stale DOI | Article the stale DOI actually resolves to | Correct DOI (verified) |
|:---|:---|:---|---:|
| `cowan1963pulse` | `10.1063/1.1729335` | *Quantum Efficiency of Ruby* (Maiman et al.) — a laser-gain paper, not the flash benchmark | `10.1063/1.1729564` (J. Appl. Phys. **34**(4):926–927) |
| `both2016deviation` | `10.1515/jnet-2015-0038` | A different article in the same journal/issue range | `10.1515/jnet-2015-0035` (J. Non-Equilib. Thermodyn. **41**(1):41–48) |
| `kovacs2018analytic` | `10.1016/j.ijheatmasstransfer.2018.07.039` | A different IJHMT article (verified record: IJHMT **127**:631–636) | `10.1016/j.ijheatmasstransfer.2018.06.082` |
| `dowding1995estimation` | `10.2514/3.670` | A different AIAA Journal of Thermophysics article | `10.2514/3.666` (J. Thermophys. Heat Transf. **9**:345–351) |

Two titles were also inaccurate: `guyer1966solution` (correct published title:
*Solution of the Linearized Phonon Boltzmann Equation*) and `li2020appropriate`
(volume 150 → **148**; title completed).

**Fix applied:** corrected in `manuscript/references.bib`, mirrored in `overleaf/references.bib`,
and propagated to `literature/literature_matrix.csv`, `literature/literature_claim_matrix.csv`
and `literature/reference_verification_master.csv` (verification flags now point at the
correct records). The bibliography was recompiled with BibTeX; three previously uncited
entries are now cited, so all 64 references appear in the printed list.

## R2. Manuscript Table 2 contradicted the shipped dataset (Critical — Gate C)

The "Peak $\theta_{\mathrm{Laplace}}$" column of Table 2 did not match
`data/validation_laplace.csv`. The archived values (extracted programmatically and
re-checked against a fresh 80-digit inversion) are:

| $Bi$ | 0 | 0.01 | 0.05 | 0.10 | 0.25 | 0.50 | 1.00 | 2.00 |
|:---|---:|---:|---:|---:|---:|---:|---:|---:|
| Peak $\theta_{\mathrm{Laplace}}$ | 0.999874 | 0.997603 | 0.989690 | 0.980862 | 0.923585 | 0.865931 | 0.774319 | 0.588985 |

**Fix applied:** Table 2 replaced with these values; the caption now defines the
$t \in [0.05, 1.0]$ output window, the pointwise relative-error norm, and the
$\tau_q = \kappa^2 = 0.01$, $B = 1$ parameter set.

## R3. Manuscript Table 3 contradicted the shipped dataset (Critical — Gate C)

The $L^2$ error column did not match `data/mesh_convergence.csv`.

| $N_x$ | 100 | 200 | 400 | 800 |
|:---|---:|---:|---:|---:|
| $L^2$ error | 5.037 × 10⁻⁵ | 1.259 × 10⁻⁵ | 3.146 × 10⁻⁶ | 7.864 × 10⁻⁷ |

**Fix applied:** Table 3 replaced with the archived values; the convergence order
$p = 2.00$ was re-confirmed by least-squares regression on these four points.

## R4. Section 5.2 trace statistics did not match Figure 6(d) (Moderate — Gate C)

The quoted $\operatorname{tr}(\mathbf{F})$ endpoints (28.0/106.3 at $N_t = 10$ and
82.2/332.1 at $N_t = 50$) were not the values plotted in Figure 6(d). The plotted
archived values are **28.2 → 105.8** ($N_t = 10$) and **82.5 → 332.5** ($N_t = 50$).

**Fix applied:** Section 5.2 corrected to the figure values.

## R5. 3D sensitivity dataset violated the manuscript's claimed accuracy floor (Critical — Gate C)

`generate_3d_datasets.py` generated `spatiotemporal_3d_sensitivities.csv` with a
degree-8 de Hoog inversion and a forward step $h = 10^{-4}$. The archived file showed
a relative collinearity defect up to **5.96 × 10⁻²** (484 of 500 rows above 10⁻⁶),
which contradicts the manuscript's claimed $\sim 10^{-8}$ floor and the point-by-point
collinearity theorem. A first repair attempt (degree 20, $h = 10^{-6}$, 40 digits)
still left a defect of 4.54 × 10⁻⁵ at the early-time pulse kink ($t = 0.04$), because
the pulse discontinuity makes the inversion marginally non-smooth in time.

**Fix applied (scientific, not cosmetic):** the generator now computes the sensitivity
fields by **analytic differentiation** of the closed-form transfer function
($\mathrm{d}\tilde{\theta}(s)/\mathrm{d}\tau_q$ and $\mathrm{d}\tilde{\theta}(s)/\mathrm{d}\kappa^2$
via `mpmath.diff` in 40-digit arithmetic), followed by a degree-20 de Hoog inversion.
The regenerated dataset shows $\max |\mathbf{J}_{\tau_q} + \alpha_0 \mathbf{J}_{\kappa^2}| = 0$
and $\max$ relative defect $= 0$ **at all 500 grid points**, exactly as the theorem
requires. The temperature and canyon datasets regenerate byte-identically to the
shipped versions. The manuscript (§5.1 text, Figure 5(c)/(d) captions) and the
plotting annotation were updated to state the analytic-differentiation result, with the
finite-difference floor ($R_J \sim 10^{-9}$) reported separately in Figure 4(d).

## R6. Precision claims exceeded the archived data (Moderate — Gate C)

* The manuscript claimed the de Hoog inversion floor is "below $10^{-55}$";
  `data/dehoog_convergence.csv` shows $10^{-56}$–$10^{-54}$ at $M = 60$. Corrected to
  the archived range.
* Section 5.4 described the finite-difference study as "twelve orders of magnitude"
  with $h = 10^{-5}$ and a "$1.36 \times 10^{-18}$" error. `run_heatloss_study.py` uses
  a **relative** step $h_{\mathrm{rel}} = 10^{-4}$ (i.e. $\Delta\tau_q = \Delta\kappa^2 = 2 \times 10^{-6}$)
  and the archived value is a **relative** defect $R_J = 1.36 \times 10^{-18}$
  (absolute $8.87 \times 10^{-19}$). Text corrected accordingly.

## R7. Regression results were not traceable (Moderate — Gate D)

The two-sided near-resonance regressions (exponent $1.00422 \pm 0.00338$, $R^2 = 0.9999546$,
$C = 1.5122$ for $B < 1$; exponent $1.00028 \pm 0.00147$, $R^2 = 0.9999914$, $C = 1.4363$
for $B > 1$) were printed to stdout only, so a reviewer could not audit them from the
package.

**Fix applied:** `run_near_resonance.py` now archives every quoted value in
`data/scaling_regression_twosided.csv` (branch, exponent, standard error, $R^2$,
intercept, linear prefactor $C$, number of points), and the file is added to the
runner's artifact-completeness check.

## R8. 3D dataset stage silently skipped regeneration (Moderate — Gate D)

`reproduce_all.py` stage 5 reused cached 3D CSV files when present, so a partial package
would still report a successful run.

**Fix applied:** the cache-skip was removed; stage 5 always regenerates (measured
205.8 s). Total pipeline runtime is 609.7 s (~10 minutes); README and manifest updated.

## R9. Literature audit document contained wrong cross-references and unverifiable citations (Moderate — Gates B/C)

`literature/contradictory_literature_audit.md` cited "Table 3" (the mesh table; the CRLB
table is Table 8) and "Figure 4b" (a thermogram panel; the two-sided regression is
Figure 9(b)), and cited four references (Pech-May 2014; Liu 2016; Mozafarifard 2020;
Numerical Heat Transfer 2024) that are not in the verified bibliography.

**Fix applied:** cross-references corrected; unsupported citations removed or replaced
by verified entries.

## R10. Q1 front-matter gaps (Moderate — submission readiness)

The manuscript lacked CRediT authorship-contribution and funding statements, and its
data-availability sentence offered data "upon reasonable request".

**Fix applied:** added a CRediT statement, a funding statement, and a data-availability
statement referencing the 18-dataset research package; the author biography now carries
the institutional block; nomenclature and symbols now include $\operatorname{cond}(\mathbf{F})$,
$\tau_{q,0}$ and $N_t$.

## R11. Stale documentation and build artifacts (Moderate — Gate D)

* `README.md`, `audit/PACKAGE_MANIFEST.md`, `audit/final_audit_report.md` and
  `program/README.md` described a superseded inventory (14 datasets, 6 figures,
  20/26-page manuscripts, a nonexistent `analytic_cowan.py` and
  `overleaf_ready.zip`, wrong CSV row counts for `validation_cowan`, `near_resonance_scaling`,
  `off_resonance_sweep` and `sensitivity_profiles`). All four documents were rewritten
  against the actual contents.
* Build artifacts removed: `manuscript/test_els.{aux,bbl,blg,log}`, `manuscript/texput.log`,
  `program/__pycache__/`, `derivations/*.toc`, and all `aux/log/blg/out/spl` files in
  `manuscript/` and `overleaf/`.

## R12. Package rebuild and verification protocol

1. `manuscript/` was recompiled (`pdflatex` → `bibtex` → `pdflatex` → `pdflatex`):
   **44 pages**, 64 printed bibitems, zero errors, zero undefined citations or
   references.
2. `derivations/guyer_krumhansl_heatloss_derivation.pdf` recompiled: **9 pages**.
3. The full pipeline was re-run end-to-end in the delivered package
   (EXIT_CODE = 0; 609.7 s measured) and every shipped CSV was compared byte-for-byte against
   the re-run output: all 18 files identical except timing columns
   (`mesh_convergence.runtime_sec`), and all 10 figure PDFs identical except the PDF
   `/CreationDate` timestamp.
4. `overleaf/` sources synchronized with `manuscript/` (main.tex, references.bib,
   elsarticle.cls, elsarticle-num.bst, figures/).

---

## Conclusion

All 12 identified defect classes were corrected at the source (data, code, and
bibliography) rather than by narrative edits alone; no result was fabricated, removed,
or re-fitted. The package is re-certified for submission under Gates A–D
(see `audit/final_audit_report.md`, Section 5 addendum).
