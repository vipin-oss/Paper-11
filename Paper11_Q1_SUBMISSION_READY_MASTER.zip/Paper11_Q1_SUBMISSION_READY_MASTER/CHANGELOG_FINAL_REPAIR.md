# CHANGELOG — Final Submission-Ready Repair Pass

**Package:** `Paper11_Q1_SUBMISSION_READY/`
**Supersedes:** `Paper11_Q1_Final/` (delivered 2026-09-27)
**Repair date:** 2026-09-28
**Nature of the pass:** scientific correction + packaging repair. No new physical results were
invented; every changed number below is a *recomputation* of a quantity that was already
claimed, using a corrected definition or a corrected numerical channel.

This document lists, for every scientific value that changed, the **old value** (as shipped in
`Paper11_Q1_Final/`) and the **new value** (as shipped here), with the reason. Values that did
not change are not listed.

---

## A. Cramér–Rao analysis moved from 2 parameters to 3 parameters (largest change)

**Reason.** The manuscript's identifiability discussion is set in the three-parameter
estimation space $\bm{p}=(\tau_q,\kappa^2,Bi)^\top$, but the shipped CRLB audit and Table 8
(`tab:crlb_analysis`) were computed from the two-parameter subsystem
$(\tau_q,\kappa^2)$. The two are not interchangeable: the 2-parameter Fisher matrix is
singular *everywhere* (because $Bi$ was dropped, not because of resonance), whereas the
3-parameter matrix is singular *only at* $B=1$. Reporting 2-parameter numbers inside a
3-parameter discussion understated the conditioning and mislabelled the mechanism. All
affected quantities were recomputed from the full three-parameter Jacobian
$\bm{J}=[\bm{J}_{\tau_q},\bm{J}_{\kappa^2},\bm{J}_{Bi}]$, obtained by **analytic
differentiation** of the closed-form transfer function in 40-digit arithmetic. The
2-parameter numbers were *not* relabelled as 3-parameter numbers — they were replaced, and
both definitions are now archived side by side in
`data/scaling_regression_twosided.csv` and Supplementary Table S5.

### A.1 Table 8 (`tab:crlb_analysis`) — 15 rows

All rows are evaluated at $B=0.99$, $Bi=0.10$, $\tau_{q,0}=0.02$.

| Configuration | $N_t$ | $\sigma_n$ | Column | Old (2-param) | New (3-param) |
| --- | --- | --- | --- | --- | --- |
| Rear-face only | 10 | 0.1% | $\sigma_{\min}/\|B-1\|$ | 1.461 | 1.438 |
| Rear-face only | 10 | 0.1% | $\mathrm{SE}(\hat\tau_q)/\sigma_n\cdot\|B-1\|$ | 0.483 | 0.491 |
| Rear-face only | 10 | 0.1% | $\|B-1\|_{\rm crit}$ (Param) | 0.242 | 0.246 |
| Rear-face only | 10 | 0.1% | $\|B-1\|_{\rm crit}$ (Singular) | 0.342 | 0.348 |
| Rear-face only | 10 | 0.5% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 1.208 / 1.711 | 1.228 / 1.739 |
| Rear-face only | 10 | 1.0% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 2.416 / 3.422 | 2.455 / 3.478 |
| Rear-face only | 50 | 0.1% | $\sigma_{\min}/\|B-1\|$ | 3.871 | 3.858 |
| Rear-face only | 50 | 0.1% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.091 / 0.129 | 0.092 / 0.130 |
| Rear-face only | 50 | 0.5% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.457 / 0.646 | 0.459 / 0.648 |
| Rear-face only | 50 | 1.0% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.914 / 1.292 | 0.917 / 1.296 |
| Rear-face only | 100 | 0.1% | $\sigma_{\min}/\|B-1\|$ | 5.501 | 5.482 |
| Rear-face only | 100 | 0.1% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.064 / 0.091 | 0.065 / 0.091 |
| Rear-face only | 100 | 0.5% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.322 / 0.454 | 0.323 / 0.456 |
| Rear-face only | 100 | 1.0% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.643 / 0.909 | 0.645 / 0.912 |
| Front + Rear | 50 | 0.1% | $\sigma_{\min}/\|B-1\|$ | 23.603 | 23.58 |
| Front + Rear | 50 | 0.1% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.015 / 0.021 | 0.015 / 0.021 |
| Front + Rear | 50 | 0.5% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.075 / 0.106 | 0.075 / 0.106 |
| Front + Rear | 50 | 1.0% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.150 / 0.212 | 0.151 / 0.212 |
| Multi-5 | 50 | 0.1% | $\sigma_{\min}/\|B-1\|$ | 24.979 | 28.17 |
| Multi-5 | 50 | 0.1% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.013 / 0.018 | 0.013 / 0.018 |
| Multi-5 | 50 | 0.5% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.063 / 0.089 | 0.063 / 0.089 |
| Multi-5 | 50 | 1.0% | $\|B-1\|_{\rm crit}$ (Param / Singular) | 0.126 / 0.178 | 0.126 / 0.177 |

Full precision (e.g. rear-face $N_t=50$: 0.091715 / 0.458573 / 0.917145 parametric and
0.129608 / 0.648040 / 1.296079 singular) is archived in `data/crlb_configuration_audit.csv`
and Supplementary Table S5.

### A.2 Effective sensitivity coefficient

| Quantity | Old (2-param) | New (3-param) |
| --- | --- | --- |
| $C_{\rm eff}$, rear-face $N_t=50$ | 3.87131 | 3.8578 ($\sigma_3/\|B-1\|$) |
| $C_{\rm eff}$, front + rear $N_t=50$ | 23.60266 | 23.581 |
| $C_{\rm eff}$, multi-5 $N_t=50$ | 24.979 | 28.172 |
| $\operatorname{cond}(\bm{F})$ prefactor, $Bi=0.10$ | 12.8646 | 14.1427 |
| $\operatorname{cond}(\bm{F})$ prefactor range over $Bi\in[0,0.5]$ | 8.683 – 14.422 | 9.438 – 16.301 |

### A.3 Near-resonance scaling prefactors

| Quantity | Old (2-param only) | New (3-param, with 2-param archived alongside) |
| --- | --- | --- |
| Branch slope $C$, $B<1$, $Bi=0.10$ | 1.5122 | 1.4814 (2-param: 1.5122) |
| Branch slope $C$, $B>1$, $Bi=0.10$ | 1.4364 | 1.4259 (2-param: 1.4364) |
| Log–log exponent, $B<1$ | 1.00722 ± 0.00263 | 1.00592 ± 0.00224 |
| Log–log exponent, $B>1$ | 0.99728 ± 0.00059 | 0.99858 ± 0.00024 |
| $R^2$, $B<1$ / $B>1$ | 0.99995 / 0.99999 | 0.999980 / 1.000000 |
| Mean prefactor $C(Bi)$ at $Bi=0.10$ | 1.4568 | 1.4357 (3-param) |
| $C(Bi)$ range over $Bi\in[0,0.5]$ | 1.384 – 1.482 | 1.348 – 1.464 |

### A.4 Generalised CRLB at exact resonance ($B=1$, Moore–Penrose)

These entries are **new**; the old package reported no estimability statement at $B=1$
beyond "$\operatorname{cond}(\bm{F})=\infty$".

| Configuration | $\operatorname{SE}(\widehat{Bi})/\sigma_n$ | $\operatorname{SE}(\widehat{\tau}_q)$ | $\operatorname{SE}(\widehat{\kappa^2})$ |
| --- | --- | --- | --- |
| Rear-face, $N_t=10$ | 0.283089 | not estimable | not estimable |
| Rear-face, $N_t=50$ | 0.124343 | not estimable | not estimable |
| Rear-face, $N_t=100$ | 0.088025 | not estimable | not estimable |
| Front + rear, $N_t=50$ | 0.084156 | not estimable | not estimable |
| Multi-5, $N_t=50$ | 0.056590 | not estimable | not estimable |

Under 1.0% noise this gives $\operatorname{SE}(\widehat{Bi})\approx1.24\times10^{-3}$, i.e. a
1.24% relative uncertainty on $Bi=0.10$ — the value already quoted in the old manuscript,
now derived from the 3-parameter pseudoinverse and archived row by row.

---

## B. Figure 10(d): hard-coded constant removed

**Reason.** The old plotting code contained the literal expression
`ratio_se = (0.183 / delta_b) / 0.1243`, i.e. a hand-typed asymptotic curve whose two
constants were pasted from an earlier analysis rather than evaluated. The curve therefore
could not be regenerated from data and its agreement with the numerical CRLB was an artefact
of construction.

| Quantity | Old | New |
| --- | --- | --- |
| $\operatorname{SE}(\hat\tau_q)/\operatorname{SE}(\widehat{Bi})$ at $\|B-1\|=0.2$ | (not evaluated) | 6.2718 |
| … at $\|B-1\|=0.01$ | (not evaluated) | 147.2454 |
| … at $\|B-1\|=10^{-3}$ | (not evaluated) | 1482.3013 |
| Fitted asymptotic prefactor $A$ | hard-coded 0.183 | 0.184565 (least squares on `uncertainty_divergence.csv`) |
| Fitted asymptotic offset $B_0$ | hard-coded 0.1243 | 0.124591 |
| Hard-coded constants in `plot_figures.py` | 2 | 0 |

Figure 10(d) now plots the numerically evaluated ratio from
`data/uncertainty_divergence.csv` and overlays a fitted $A/|B-1|$ asymptote that is
**explicitly labelled as a fit**, with the $B=1$ row marked "not estimable" (the FIM is
structurally singular there). The same audit is reproduced as Supplementary Table S5.

---

## C. Null-vector convention made explicit and consistent

**Reason.** The structural null direction was written as $(1,\alpha_0,0)^\top$ in some
places and $(1,1,0)^\top$ in others without stating which parameter set was meant, which
reads as an inconsistency (or a typo) to a reviewer.

| Context | Old | New |
| --- | --- | --- |
| Dimensionless parameters $(\tau_q,\kappa^2,Bi)$ scaled by $\alpha_0$ | mixed / unstated | $\bm{v}_{\rm null}=(1,1,0)^\top$ |
| Dimensional parameters $(\tau_q,\kappa^2,Bi)$ | mixed / unstated | $\bm{v}_{\rm null}=(1,\alpha_0,0)^\top$ |
| Manuscript, derivations, code, figure captions, README | inconsistent | one convention, stated at first use and repeated in every location |

The two forms are the same geometric fact in different coordinates; the manuscript now says
so explicitly.

---

## D. Condition-number convention at exact resonance ($B=1$)

**Reason.** `canyon_3d_landscape.csv` stored $\log_{10}\operatorname{cond}$ values around
16–17 at $B=1$ while the code took an "exact resonance" branch with its own convention, and
Figure 8 plotted the stored value without explanation. A reviewer reads a finite condition
number at a point where the matrix is provably singular as an error.

| Quantity | Old | New |
| --- | --- | --- |
| $\operatorname{cond}(\bm{F})$ at $B=1$ (analytical) | reported as a finite number | stated to be **infinite** |
| $\operatorname{cond}(\bm{F})$ at $B=1$ (stored value) | unexplained $10^{16}$–$10^{17}$ | identified as the IEEE 754 double-precision evaluation floor, flagged by the `cond_F_at_numerical_floor` column |
| Canyon grid, $Bi=0.10$, $B=1$ | — | $\sigma=[5.6007,\,4.2515,\,1.6\times10^{-16}]$, $\operatorname{cond}=1.078\times10^{16}$ (numerical floor) |
| Canyon grid, $Bi=0.10$, $B=0.95$ / $1.05$ | — | $\operatorname{cond}\approx6.0\times10^{3}$, $\sigma_3\approx7.2\times10^{-2}$ (genuinely finite) |
| Canyon grid, $Bi=0.10$, $B=0.5$ | — | $\operatorname{cond}=52.7$ |
| Figure 8 | single unannotated value | annotated convention: floor vs. genuine conditioning |

---

## E. "Exactly zero" claims replaced by channel-specific floors

**Reason.** Floating-point computation cannot produce an exact zero; claiming
"$\sigma_3$ is exactly zero at all 500 grid points" invites a reproducibility objection.

| Quantity | Old | New |
| --- | --- | --- |
| Collinearity defect, analytic-differentiation channel | "exactly zero at all 500 grid points" | identically zero in exact arithmetic; the analytic channel returns it as zero to below double-precision unit roundoff |
| Collinearity defect, finite-difference channel ($h_{\rm rel}=10^{-4}$) | not reported | peak $2.72\times10^{-5}$ at $(x=0,\,t=0.04)$; $\sim10^{-9}$ elsewhere |
| 3D sensitivity grid, FD channel maximum defect | $4.5\times10^{-5}$ (unqualified) | $4.538\times10^{-5}$, explicitly labelled a truncation floor |
| $\sigma_3$ at resonance | "exactly zero" | analytically identically zero; every non-zero computed value is a truncation or round-off floor of its evaluation channel |
| $R_J\sim10^{-9}$ in 64-bit arithmetic | presented as a residual | identified as a finite-difference truncation effect, not a breakdown of the analytical identity |

---

## F. Power-law residual claim corrected

**Reason.** §5.4 asserted that the single-prefactor linear asymptote reproduces
$\sigma_{\min}$ to "better than 0.1% relative residual for $|B-1|\le0.05$". Recomputing the
residuals directly from `near_resonance_scaling.csv` (Bi = 0.10, 3-parameter $\sigma_3$,
branch constants 1.481404 / 1.425860) gives materially larger values.

| Quantity | Old | New |
| --- | --- | --- |
| Max relative residual, $B<1$, $\|B-1\|\le0.1$ | "< 0.1%" | 3.21% |
| Max relative residual, $B>1$, $\|B-1\|\le0.1$ | "< 0.1%" | 0.62% |
| Residual at $\|B-1\|=0.1$ | "< 0.1%" | +0.020% (left) / +0.027% (right) |
| Residual at $\|B-1\|=0.5$ | not stated | +33.7% (left) / −2.7% (right) |
| Figure 9(d) caption | implied sub-0.1% accuracy | states the 3.3% / 0.7% values and that the residual grows outside the fit range |

---

## G. Packaging, documentation and build repairs

| Item | Old | New |
| --- | --- | --- |
| Canonical manuscript | two copies (`manuscript/`, `overleaf/`) that could drift | one canonical `manuscript/main.tex`; `overleaf/` is a byte-identical mirror of the sources |
| Data archive | 17 CSV files | 19 CSV files (added `scaling_regression_twosided.csv`, `uncertainty_divergence.csv`) |
| Precision/convergence audits | 2 tables inside the main manuscript | moved to `supplementary/` as Tables S1 and S2; in-text references repointed to "Supplementary Table S1/S2" |
| Supplementary material | absent | `supplementary/supplementary_material.tex` + PDF, 6 pages, Tables S1–S6, generated from the shipped CSVs by `program/make_supplementary.py` |
| Reproducibility runner | 6 stages | 7 stages (adds supplementary-table generation) + supplementary completeness check in `run_manifest.json` |
| Manuscript length | 44 pages | 47 pages (+6 pages supplementary) |
| Bibliography | 64 entries, 4 wrong DOIs, 2 wrong titles | 64 entries, all re-verified against Crossref (September 2026) |
| Undefined references / overfull boxes | 1 undefined reference, 7 overfull boxes | 0 / 0 |
| Data availability | unverifiable public-archive claim | truthful statement: provided with the submission materials and archived publicly upon acceptance |
| Experimental framing | experimental-sounding claims | explicitly a theoretical and computational study; no experiments performed |
| ASTM E1461 | implied reliance on the standard | explicit demarcation: the study does not rely on, extend, or modify the standard |
| Novelty claims | unqualified "first" statements | "to the best of our literature search (September 2026)" |
| Internal audit material | interleaved with reviewer-facing files | isolated in `INTERNAL_AUDIT/`, cited by no reviewer-facing file |
| Directory layout | flat mixed package | `manuscript/`, `program/`, `data/`, `figures/`, `supplementary/`, `overleaf/`, `derivations/`, `INTERNAL_AUDIT/` |

---

## H. Values deliberately **not** changed

These were re-derived and confirmed identical, and are listed so that a reviewer can see they
were checked rather than overlooked:

- Validation benchmarks: $L^\infty \le 1.02\times10^{-5}$ (Laplace channel) against the
  time-domain PDE solver; Cowan series agreement; mesh order $p=2.00$.
- de Hoog truncation floor $10^{-56}$–$10^{-54}$ at $M=60$; FD step $h_{\rm rel}=10^{-4}$.
- Field-level invariance residuals $10^{-24}$–$10^{-29}$ at 50-digit precision.
- Off-resonance classical-limit prefactor $C_{\rm asymp}=3.928$.
- Observable-subspace conditioning $\sigma_1/\sigma_2\in[2.34,\,4.90]$; $\rho\equiv-1$.
- Trace growth $\operatorname{tr}(\bm{F}) = 28.2\to105.8$ ($N_t=10$) and
  $82.5\to332.5$ ($N_t=50$) for the front+rear configuration.

---

## Second pass: release lock (2026-09-28)

Surgical cleanup applied after the scientific repairs above. **No numerical result,
equation, figure or reference was changed.** Seven fixes:

| # | Fix | Files touched |
| --- | --- | --- |
| 1 | "activating nonlinear transport regimes would be required" replaced by qualified wording: linear boundary dissipation / multi-sensor detection alone do not regularize *within the present model*; mechanisms altering the bulk transport operator *may* provide a route but their identifiability consequences require separate analysis | `manuscript/main.tex` (2 edits) |
| 2 | Thickness claim recast as "may amplify ... could help move ... outside the scope of the present fixed-geometry analysis" | `manuscript/main.tex` (1 edit) |
| 3 | "all 19 CSVs regenerate bit-for-bit" corrected to "18 of the 19 ... except the wall-clock `runtime_sec` field" | `REPRODUCIBILITY.md`, `README.md`, `program/README.md` |
| 4 | `compile.sh` hardened: `set -euo pipefail`, `command -v pdflatex` / `command -v bibtex` guards that exit 1 without producing or modifying a PDF, intermediate cleanup, final warning report; required TeX tools documented in `README.md` and `REPRODUCIBILITY.md` | `manuscript/compile.sh` (rewritten), `overleaf/compile.sh` (byte-identical copy), `README.md`, `REPRODUCIBILITY.md` |
| 5 | `Paper11_Journal_Submission.zip` — `manuscript/` + `supplementary/` only; all internal audit material excluded | package |
| 6 | `Paper11_Reproducibility_Package.zip` — `program/`, `data/`, `figures/`, `derivations/`, purpose-written `README.md`, `REPRODUCIBILITY.md`, `requirements.txt`, `run_manifest.json`; no public-archive claim | package |
| 7 | `Paper11_Q1_SUBMISSION_READY_MASTER.zip` retained as the private master (includes `INTERNAL_AUDIT/`); three roles kept strictly separate, no nesting | package |

Supporting code change: `program/make_supplementary.py` now creates its output directory
if absent (`os.makedirs(..., exist_ok=True)`), so the script also works in a package that
ships only `program/` and `data/`. Output remains byte-identical.

**Verification result:** 20/20 release-lock checks passed. The manuscript recompiles from
the shipped package to 47 pages with 0 undefined references and 0 overfull boxes; the
supplementary material to 6 pages; the reproducibility package regenerates the
supplementary tables byte-for-byte and 10/10 figures identically (PDF creation timestamp
excluded); all 19 CSVs and all 20 figure files are byte-identical to the input package.
Full detail in `Paper11_Final_Release_Notes.md`.
