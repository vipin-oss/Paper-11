# Reproducibility Package - Paper 11

**Invariance of the Guyer-Krumhansl Fourier-Resonance Sensitivity Singularity to Boundary
Heat Loss in Laser Flash Testing**

**Author:** Dr. Vipin Gupta - Department of Mathematics, Gurugram University, Gurugram,
Haryana 122018, India - `vipin.gupta@gurugramuniversity.ac.in`

---

## What this package is

Everything needed to reproduce the computational results of the manuscript: the complete
numerical pipeline, the 19 archived datasets that every quoted number is traceable to, the
10 publication figures, and the analytical derivations.

This is a **theoretical and computational** study. No physical experiment was performed and
no measured thermogram is reported.

## Software requirements

| Component | Version used for the shipped results |
| --- | --- |
| Python | 3.13.14 |
| NumPy | 2.3.5 |
| SciPy | 1.17.1 |
| mpmath | 1.3.0 |
| Matplotlib | 3.10.9 |
| pandas | 2.2.3 |

Forward-compatible with NumPy >= 1.24, SciPy >= 1.10, mpmath >= 1.3, Matplotlib >= 3.7 and
pandas >= 2.0. No GPU, no network access and no proprietary solver are required.

To compile the LaTeX manuscript and supplementary material (supplied in the separate journal
submission package) you additionally need a TeX installation providing **both `pdflatex` and
`bibtex`**, e.g. on Debian/Ubuntu:

```bash
sudo apt-get install texlive-latex-base texlive-latex-recommended \
                     texlive-fonts-recommended texlive-latex-extra
```

## Installation

```bash
pip install -r requirements.txt
```

## Contents

| Path | Content |
| --- | --- |
| `program/` | 11 Python modules: the coupled GK-Robin PDE solver, the Laplace-domain transfer functions, the independent Talbot/Cowan/FVM benchmarks, the 3D dataset generators, the near-resonance and CRLB studies, the field-verification studies, the figure plotter, the supplementary-table generator, and the master runner |
| `program/requirements.txt` | Pinned Python environment (also at the package root as `requirements.txt`) |
| `program/README.md` | Module-by-module documentation and measured stage runtimes |
| `data/` | 19 CSV datasets: validation benchmarks, convergence studies, parameter sweeps, near-resonance scaling, the two-sided regression audit, the 54-row CRLB audit, the uncertainty-divergence scan, the 3D spatiotemporal grids, and the high-precision field residuals |
| `figures/` | The 10 publication figures, vector PDF and 300-DPI PNG |
| `derivations/` | Analytical proofs and derivations (Markdown, LaTeX source, compiled PDF) |
| `README.md` | This file |
| `REPRODUCIBILITY.md` | Environment, numerical settings, runtimes, byte-level reproduction protocol |
| `run_manifest.json` | Machine-readable log of the last full pipeline run |

## How to regenerate the data

```bash
python3 program/reproduce_all.py      # full end-to-end pipeline, ~11 minutes
```

This runs all seven stages in order: validation benchmarks, resonance heat-loss sweeps, the
near-resonance landscape and two-sided regressions, the 54-row CRLB audit, high-precision
field verification, the 3D spatiotemporal datasets, the 10 publication figures, and the
supplementary tables. It writes `run_manifest.json` with per-stage runtimes, the software
environment and artifact-completeness checks.

Individual stages can also be run on their own, for example
`python3 program/run_near_resonance.py`.

## How to regenerate the figures

```bash
python3 program/plot_figures.py       # ~1 minute, reads only data/
```

`plot_figures.py` also mirrors each figure into `manuscript/figures/` and `overleaf/figures/`
so that the LaTeX sources always pick up the current figures; in this package those two
directories are created on demand by the script and can be ignored - the authoritative
copies are in `figures/`.

## How to regenerate the supplementary tables

```bash
python3 program/make_supplementary.py # reads only data/, creates supplementary/ if absent
```

## How to compile the manuscript

The LaTeX sources, the pre-compiled `main.bbl`, and `compile.sh` are in the journal
submission package. From that package:

```bash
cd manuscript && bash compile.sh      # pdflatex, bibtex, pdflatex, pdflatex
cd ../supplementary && pdflatex supplementary_material.tex && pdflatex supplementary_material.tex
```

`compile.sh` checks that `pdflatex` and `bibtex` are available and exits with an error
without producing a PDF if either is missing; it never reuses a stale `main.pdf`.

## Deterministic versus runtime-dependent outputs

- **18 of the 19 CSV datasets regenerate byte-for-byte.**
- `data/mesh_convergence.csv` is scientifically deterministic except for its wall-clock
  `runtime_sec` field, which records the measured solve time of each mesh refinement and
  therefore varies between runs. Every other column of that file (grid spacing, L-infinity
  and L2 errors, observed convergence order) regenerates exactly.
- **All 10 figure PDFs regenerate byte-for-byte**, apart from the PDF `/CreationDate`
  metadata timestamp.
- `run_manifest.json` records wall-clock runtimes and therefore differs between runs.

The `runtime_sec` column is kept deliberately: it is a genuine performance measurement of the
conservative-FVM solver at each mesh resolution.

## Data availability

All datasets, code, figures and derivations in this package are provided with the submission
materials. Upon acceptance they will be archived in a public repository and a persistent
identifier will be added to the manuscript's data-availability statement. **No public archive
link exists at this stage and none is claimed.**

## Contact

Dr. Vipin Gupta - `vipin.gupta@gurugramuniversity.ac.in`
