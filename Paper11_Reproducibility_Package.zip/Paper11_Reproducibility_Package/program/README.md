# Paper 11 — Computational Simulation Pipeline

This directory contains the complete numerical simulation, verification, and plotting
pipeline supporting the manuscript *"Invariance of the Guyer–Krumhansl Fourier-Resonance
Sensitivity Singularity to Boundary Heat Loss in Laser Flash Testing"*.

## Environment Requirements

| Package | Version (verified reference environment) |
|:---|:---|
| Python | 3.13.14 |
| NumPy | 2.3.5 |
| SciPy | 1.17.1 |
| mpmath | 1.3.0 |
| Matplotlib | 3.10.9 |
| pandas | 2.2.3 |

Install with:

```bash
pip install -r requirements.txt
```

The pipeline is also forward-compatible with older stable releases (NumPy ≥ 1.24,
SciPy ≥ 1.10, mpmath ≥ 1.3, Matplotlib ≥ 3.7, pandas ≥ 2.0).

## Path Resolution

All modules resolve their input and output locations relative to this file's own
directory (`Path(__file__).resolve().parent`), and locate the package root one level
up. They can therefore be launched from any working directory (e.g.
`python3 /path/to/program/reproduce_all.py` from `/` or from the package root) and
will always read and write inside the package `data/` and `figures/` directories.

## Module Inventory

| Module | Responsibility |
|:---|:---|
| `solver_gk_heatloss.py` | Staggered-grid BDF (θ(α) = 0.5) finite-difference solver for the coupled GK system with Robin convective–radiative heat loss; simulates the laser flash pulse and the transient response; provides `simulate_gk_slab()` and the conservative Finite Volume Method benchmark. |
| `analytic_laplace.py` | Closed-form Laplace-domain transfer functions (field, rear-face, dynamic thermal conductivity), analytic temperature gradients, exact Cowan (1963) Fourier eigenvalue series, de Hoog Padé inversion, high-precision field sweeps and mesh/step-size convergence studies. |
| `independent_solver.py` | Fully independent verification stack: modified Talbot contour inversion, exact 50-root Cowan eigenfunction series, and conservative FVM discretization, used as the third-party benchmark in Tables 1–3 and Figures 3–4. |
| `generate_3d_datasets.py` | Generates the 3D spatiotemporal grids (`spatiotemporal_3d_temperature.csv`, `spatiotemporal_3d_sensitivities.csv`, `canyon_3d_landscape.csv`). Temperature and condition-number fields are inverted by the de Hoog algorithm (degree 20, 15 significant digits). **The sensitivity fields are obtained by analytic differentiation of the closed-form transfer function with respect to τ_q, κ² and Bi in 40-digit arithmetic** (via `mpmath.diff`), so the collinearity defect J_{τ_q} + α₀J_{κ²} is identically zero in this channel (returned as zero to below double-precision unit roundoff). An independent central finite-difference channel (relative step h_rel = 10⁻⁴) is computed alongside and archived in the same CSV; its residual is a truncation floor, peaking at 4.538 × 10⁻⁵, and is reported as such. |
| `run_validation.py` | Runs the two PDE verification benchmarks (continuous Laplace inversion and exact Cowan series) and the conservative FVM mesh-convergence study; writes `validation_laplace.csv`, `validation_cowan.csv`, `mesh_convergence.csv`. Relative error is the pointwise maximum of \|θ_PDE − θ_bench\| / (\|θ_bench\| + 10⁻¹²) over the 20-point output window t ∈ [0.05, 1.0]. |
| `run_heatloss_study.py` | Sweeps Bi₀ = Bi_L ∈ [0.001, 0.5] at exact resonance; computes sensitivity-vector correlations, Fisher singular values and condition numbers, and the full sensitivity time profiles; writes `heatloss_parameter_sweep.csv`, `sensitivity_profiles.csv`. |
| `run_near_resonance.py` | Near-resonance SVD study (B ∈ [0.5, 1.5], refined toward B = 1), the two-sided linear regressions, the wide off-resonance sweep, and the 54-row CRLB audit (27 near-resonance configurations at B = 0.99 plus 27 at B = 1 with the Moore–Penrose generalized bound) and the uncertainty-divergence scan; writes `near_resonance_scaling.csv`, `off_resonance_sweep.csv`, `scaling_summary.csv`, `scaling_regression_twosided.csv`, `crlb_configuration_audit.csv`, `uncertainty_divergence.csv`. |
| `run_field_verification.py` | 50-digit continuous Laplace field verification across interior stations and asymmetric cooling pairs, plus interior-point mesh refinement and the finite-difference step-size study; writes `field_invariance_asymmetric.csv`, `interior_point_mesh_refinement.csv`, `sensitivity_step_size_convergence.csv`, `asymptotic_fourier_convergence.csv`, `dehoog_convergence.csv`. |
| `plot_figures.py` | Reads only the shipped CSV datasets and renders the full 10-figure publication suite (vector PDF + 300-DPI PNG) into `figures/`, `manuscript/figures/` and `overleaf/figures/`. |
| `make_supplementary.py` | Generates `supplementary/supplementary_material.tex` (Tables S1–S6) directly from the shipped CSV datasets, so the supplementary tables can never drift from the data. |
| `reproduce_all.py` | Master runner: executes every generation stage in order, verifies artifact completeness, and writes `run_manifest.json` with measured per-stage runtimes and the software environment. |

## Execution

### Regenerate the figures only (~1 minute)

```bash
python3 plot_figures.py
```

### Full end-to-end reproduction (~15–20 minutes)

```bash
python3 reproduce_all.py
```

Reference timings for each stage on the verified environment:

| Stage | Description | Measured time |
|:---|---|:---:|
| 1 | `run_validation.py` (Laplace + Cowan benchmarks, mesh refinement) | 78.03 s |
| 2 | `run_heatloss_study.py` (heat-loss sweep, sensitivity profiles) | 27.39 s |
| 3 | `run_near_resonance.py` (SVD scaling, two-sided regression, 54-row CRLB audit, divergence scan) | 113.83 s |
| 4 | `run_field_verification.py` (50-digit field, step-size study) | 22.03 s |
| 5 | `generate_3d_datasets.py` (3D temperature, sensitivities, canyon) | 355.44 s |
| 6 | `plot_figures.py` (10-figure publication suite) | 43.14 s |
| 7 | `make_supplementary.py` (supplementary Tables S1–S6) | 0.64 s |
| **Total** | | 640.5 s |

Per-stage execution time is also recorded automatically in `run_manifest.json`.

## Numerical Notes

* **Sensitivity floors.** At exact resonance the analytic collinearity residual is zero by
  construction; the finite-difference channel used for the independent step-size study
  (relative step $h_{\mathrm{rel}} = 10^{-4}$, i.e. Δτ_q = Δκ² = 2 × 10⁻⁶) bottoms out at
  a relative defect $R_J \sim 10^{-9}$.
* **Laplace inversion.** The de Hoog quotient-difference algorithm (degree 20 for the
  datasets, degree up to 60 for the convergence study) attains $10^{-56}$–$10^{-54}$
  absolute error at 50–80 digit precision; the archived precision table is
  `data/dehoog_convergence.csv`.
* **Condition number at resonance.** At B = 1 the three-parameter Fisher Information
  Matrix is structurally singular and its condition number is **analytically infinite**.
  The finite values (~10¹⁶–10¹⁷) stored in `data/canyon_3d_landscape.csv` and
  plotted in Figures 7–8 are the IEEE 754 double-precision evaluation floor of the
  numerical channel; they are flagged by the `cond_F_at_numerical_floor` column and must
  not be read as physical condition numbers. Away from resonance (e.g. B = 0.95 or
  B = 1.05) the stored values are genuine finite condition numbers.
* **Determinism.** All simulations use fixed random-seed-free deterministic algorithms
  and fixed mesh/output grids, so repeated runs reproduce 18 of the 19 shipped CSV
  datasets byte-for-byte. The exception is `data/mesh_convergence.csv`, whose
  `runtime_sec` column records a wall-clock measurement and therefore varies between runs;
  every scientific column of that file (grid spacing, errors, convergence order) is
  deterministic. Figure PDFs likewise reproduce byte-for-byte apart from their creation
  timestamp.
* **Supplementary tables.** `make_supplementary.py` reads only the archived CSVs, so the
  supplementary material is regenerated, never hand-edited.
