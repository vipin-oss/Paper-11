# Comprehensive Mathematical Derivations: Guyer–Krumhansl Conduction with Boundary Heat Loss

**Author:** Vipin Gupta  
**Affiliation:** Department of Mathematics, Gurugram University, Gurugram, Haryana 122018, India  
**Date:** September 2026 (Audited & Revised for Q1 Submission)  

---

## 1. Dimensional Governing Equations & Physical Formulation

Consider a rigid, homogeneous, isotropic solid slab of thickness $L$, initially at a uniform equilibrium reference temperature $T_0$. At time $t = 0$, the front boundary ($x = 0$) is irradiated by a transient laser pulse delivering an absorbed heat flux $q_{\mathrm{laser}}(t)$. Simultaneously, both front ($x = 0$) and rear ($x = L$) faces exchange heat with the surrounding environment via linearized convection and radiation.

### 1.1 Energy Conservation Equation
In one-dimensional planar geometry, thermal energy conservation in the absence of internal volumetric heat generation is:
$$\rho c \frac{\partial T}{\partial t} + \frac{\partial q}{\partial x} = 0 \tag{1}$$
where:
- $\rho$ is mass density $[\mathrm{kg \cdot m^{-3}}]$,
- $c$ is specific heat capacity $[\mathrm{J \cdot kg^{-1} \cdot K^{-1}}]$,
- $\rho c$ is volumetric heat capacity $[\mathrm{J \cdot m^{-3} \cdot K^{-1}}]$,
- $T(x, t)$ is absolute temperature $[\mathrm{K}]$,
- $q(x, t)$ is heat flux in the $+x$ direction $[\mathrm{W \cdot m^{-2}}]$.

**Dimensional Verification of Eq. (1):**
$$\left[\rho c \frac{\partial T}{\partial t}\right] = \frac{\mathrm{J}}{\mathrm{m^3 \cdot K}} \cdot \frac{\mathrm{K}}{\mathrm{s}} = \frac{\mathrm{J}}{\mathrm{m^3 \cdot s}} = \frac{\mathrm{W}}{\mathrm{m^3}}$$
$$\left[\frac{\partial q}{\partial x}\right] = \frac{\mathrm{W \cdot m^{-2}}}{\mathrm{m}} = \frac{\mathrm{W}}{\mathrm{m^3}}$$
Both terms possess identical dimensions of volumetric power density $[\mathrm{W \cdot m^{-3}}]$.

---

### 1.2 Guyer–Krumhansl Constitutive Equation
To account for non-equilibrium phonon hydrodynamic transport involving both temporal memory and non-local spatial momentum exchange, we adopt the Guyer–Krumhansl (GK) rate equation:
$$\tau_q \frac{\partial q}{\partial t} + q + \lambda_0 \frac{\partial T}{\partial x} - \kappa^2 \frac{\partial^2 q}{\partial x^2} = 0 \tag{2}$$
where:
- $\tau_q$ is the thermal relaxation time of the heat carriers $[\mathrm{s}]$,
- $\lambda_0$ is the baseline Fourier thermal conductivity $[\mathrm{W \cdot m^{-1} \cdot K^{-1}}]$,
- $\kappa^2 = \ell^2$ is the non-local mean-free-path square parameter $[\mathrm{m^2}]$, representing the spatial range of momentum-conserving normal phonon scattering.

**Dimensional Verification of Eq. (2):**
$$\left[\tau_q \frac{\partial q}{\partial t}\right] = \mathrm{s} \cdot \frac{\mathrm{W \cdot m^{-2}}}{\mathrm{s}} = \mathrm{W \cdot m^{-2}}$$
$$[q] = \mathrm{W \cdot m^{-2}}$$
$$\left[\lambda_0 \frac{\partial T}{\partial x}\right] = \frac{\mathrm{W}}{\mathrm{m \cdot K}} \cdot \frac{\mathrm{K}}{\mathrm{m}} = \mathrm{W \cdot m^{-2}}$$
$$\left[\kappa^2 \frac{\partial^2 q}{\partial x^2}\right] = \mathrm{m^2} \cdot \frac{\mathrm{W \cdot m^{-2}}}{\mathrm{m^2}} = \mathrm{W \cdot m^{-2}}$$
All four terms possess identical dimensions of areal heat flux $[\mathrm{W \cdot m^{-2}}]$.

The baseline thermal diffusivity is defined by:
$$\alpha_0 = \frac{\lambda_0}{\rho c} \quad [\mathrm{m^2 \cdot s^{-1}}].$$

---

## 2. Robin Boundary Conditions and Outward Normal Derivation

Let $\theta(x, t) \equiv T(x, t) - T_0$ denote the temperature rise above ambient. The outward unit normal vectors to the 1D domain $[0, L]$ are:
$$\bm{n}(0) = -\hat{\bm{x}}, \qquad \bm{n}(L) = +\hat{\bm{x}}.$$

The physical heat exchange at each boundary comprises outward convective and radiative cooling into the ambient environment at $T_0$, alongside incoming laser irradiation at the irradiated surface.

### 2.1 Front Boundary ($x = 0$)
The outward heat flux leaving the domain through surface cooling is:
$$\bm{q}_{\mathrm{loss}} \cdot \bm{n}(0) = -q_{\mathrm{loss}}(0, t) = h_0 [T(0, t) - T_0] = h_0 \theta(0, t)$$
$$\implies q_{\mathrm{loss}}(0, t) = -h_0 \theta(0, t)$$
The external laser source delivers heat into the domain in the $+\hat{\bm{x}}$ direction:
$$q_{\mathrm{laser}}(t) > 0.$$
Therefore, the net heat flux in the $+x$ direction entering the domain at $x = 0$ is:
$$q(0, t) = q_{\mathrm{laser}}(t) - h_0 \theta(0, t) \tag{3a}$$
where $h_0 = h_{\mathrm{conv}, 0} + 4 \varepsilon_0 \sigma_{\mathrm{SB}} T_0^3$ is the linearized total heat transfer coefficient.

### 2.2 Rear Boundary ($x = L$)
At the rear surface, no external irradiation is present. The outward heat flux leaving the domain into the ambient environment is:
$$\bm{q} \cdot \bm{n}(L) = q(L, t) = h_L [T(L, t) - T_0] = h_L \theta(L, t) \tag{3b}$$
where $h_L = h_{\mathrm{conv}, L} + 4 \varepsilon_L \sigma_{\mathrm{SB}} T_0^3$.

### 2.3 Initial Conditions
The sample is initially at uniform ambient equilibrium:
$$\theta(x, 0) = 0, \qquad q(x, 0) = 0 \quad \forall x \in [0, L] \tag{4}$$

---

## 3. Rigorous Nondimensionalization

We define characteristic reference scales:
- Length scale: $x_{\mathrm{ref}} = L$,
- Time scale: $t_{\mathrm{ref}} = \frac{L^2}{\alpha_0}$ (characteristic thermal diffusion time across the slab),
- Heat flux scale: $q_{\mathrm{ref}} = q_{\max}$,
- Temperature rise scale: $\Delta T_{\mathrm{ref}} = \frac{q_{\max} t_p}{\rho c L}$, representing the adiabatic adiabatic equilibrium temperature rise resulting from the total absorbed pulse energy.

We introduce dimensionless coordinates and state variables (marked with hats):
$$\hat{x} = \frac{x}{L} \in [0, 1], \quad \hat{t} = \frac{t}{t_{\mathrm{ref}}} = \frac{\alpha_0 t}{L^2}, \quad \hat{\theta} = \frac{\theta}{\Delta T_{\mathrm{ref}}}, \quad \hat{q} = \frac{q}{q_{\max}}.$$

### 3.1 Transformation of Energy Conservation
Substituting into Eq. (1):
$$\rho c \frac{\Delta T_{\mathrm{ref}}}{t_{\mathrm{ref}}} \frac{\partial \hat{\theta}}{\partial \hat{t}} + \frac{q_{\max}}{L} \frac{\partial \hat{q}}{\partial \hat{x}} = 0$$
$$\frac{\rho c \left(\frac{q_{\max} t_p}{\rho c L}\right)}{\frac{L^2}{\alpha_0}} \frac{\partial \hat{\theta}}{\partial \hat{t}} + \frac{q_{\max}}{L} \frac{\partial \hat{q}}{\partial \hat{x}} = 0$$
$$\frac{q_{\max}}{L} \left( \frac{\alpha_0 t_p}{L^2} \right) \frac{\partial \hat{\theta}}{\partial \hat{t}} + \frac{q_{\max}}{L} \frac{\partial \hat{q}}{\partial \hat{x}} = 0$$
Dividing by $q_{\max}/L$ and defining the dimensionless pulse width parameter:
$$\tau_\Delta \equiv \frac{\alpha_0 t_p}{L^2} \tag{5}$$
yields the dimensionless energy balance equation:
$$\tau_\Delta \frac{\partial \hat{\theta}}{\partial \hat{t}} + \frac{\partial \hat{q}}{\partial \hat{x}} = 0 \tag{6}$$

---

### 3.2 Transformation of the GK Constitutive Equation
Substituting into Eq. (2):
$$\tau_q \frac{q_{\max}}{t_{\mathrm{ref}}} \frac{\partial \hat{q}}{\partial \hat{t}} + q_{\max} \hat{q} + \lambda_0 \frac{\Delta T_{\mathrm{ref}}}{L} \frac{\partial \hat{\theta}}{\partial \hat{x}} - \kappa^2 \frac{q_{\max}}{L^2} \frac{\partial^2 \hat{q}}{\partial \hat{x}^2} = 0$$
Dividing through by $q_{\max}$:
$$\left(\frac{\alpha_0 \tau_q}{L^2}\right) \frac{\partial \hat{q}}{\partial \hat{t}} + \hat{q} + \frac{\lambda_0 \left(\frac{q_{\max} t_p}{\rho c L}\right)}{q_{\max} L} \frac{\partial \hat{\theta}}{\partial \hat{x}} - \left(\frac{\kappa^2}{L^2}\right) \frac{\partial^2 \hat{q}}{\partial \hat{x}^2} = 0$$
Notice that:
$$\frac{\lambda_0 t_p}{\rho c L^2} = \frac{\alpha_0 t_p}{L^2} \equiv \tau_\Delta.$$
We define the dimensionless relaxation time and dimensionless non-local parameter:
$$\hat{\tau}_q \equiv \frac{\alpha_0 \tau_q}{L^2}, \qquad \hat{\kappa}^2 \equiv \frac{\kappa^2}{L^2} \tag{7}$$
Equation (2) becomes:
$$\hat{\tau}_q \frac{\partial \hat{q}}{\partial \hat{t}} + \hat{q} + \tau_\Delta \frac{\partial \hat{\theta}}{\partial \hat{x}} - \hat{\kappa}^2 \frac{\partial^2 \hat{q}}{\partial \hat{x}^2} = 0 \tag{8}$$

---

### 3.3 Transformation of Robin Boundary Conditions
At $x = 0$:
$$q(0, t) = q_{\mathrm{laser}}(t) - h_0 \theta(0, t)$$
$$\hat{q}(0, \hat{t}) = \frac{q_{\mathrm{laser}}(t)}{q_{\max}} - \frac{h_0 \Delta T_{\mathrm{ref}}}{q_{\max}} \hat{\theta}(0, \hat{t})$$
Evaluating the heat-loss prefactor:
$$\frac{h_0 \Delta T_{\mathrm{ref}}}{q_{\max}} = \frac{h_0 \left(\frac{q_{\max} t_p}{\rho c L}\right)}{q_{\max}} = \frac{h_0 t_p}{\rho c L} = \left(\frac{h_0 L}{\lambda_0}\right) \left(\frac{\alpha_0 t_p}{L^2}\right) = Bi_0 \, \tau_\Delta$$
where the front-surface Biot number is defined by:
$$Bi_0 \equiv \frac{h_0 L}{\lambda_0} \tag{9a}$$
Defining the normalized laser pulse shape $\hat{q}_{\mathrm{pulse}}(\hat{t}) \equiv q_{\mathrm{laser}}(t) / q_{\max}$, the front boundary condition is:
$$\hat{q}(0, \hat{t}) = \hat{q}_{\mathrm{pulse}}(\hat{t}) - \tau_\Delta Bi_0 \hat{\theta}(0, \hat{t}) \tag{10a}$$

At the rear surface $x = L$ ($\hat{x} = 1$):
$$q(L, t) = h_L \theta(L, t)$$
$$\hat{q}(1, \hat{t}) = \frac{h_L \Delta T_{\mathrm{ref}}}{q_{\max}} \hat{\theta}(1, \hat{t}) = \tau_\Delta Bi_L \hat{\theta}(1, \hat{t}) \tag{10b}$$
where the rear-surface Biot number is defined by:
$$Bi_L \equiv \frac{h_L L}{\lambda_0} \tag{9b}$$

Dropping hats henceforth for clarity of notation, the dimensionless governing boundary-value problem is:
$$\tau_\Delta \frac{\partial \theta}{\partial t} + \frac{\partial q}{\partial x} = 0 \tag{11}$$
$$\tau_q \frac{\partial q}{\partial t} + q + \tau_\Delta \frac{\partial \theta}{\partial x} - \kappa^2 \frac{\partial^2 q}{\partial x^2} = 0 \tag{12}$$
subject to:
$$q(0, t) = q_{\mathrm{pulse}}(t) - \tau_\Delta Bi_0 \theta(0, t) \tag{13a}$$
$$q(1, t) = \tau_\Delta Bi_L \theta(1, t) \tag{13b}$$
$$\theta(x, 0) = 0, \qquad q(x, 0) = 0 \tag{13c}$$

---

## 4. Laplace-Domain Elimination and Modal Completeness

Applying the one-sided Laplace transform $\bar{f}(x, s) = \int_0^\infty f(x, t) e^{-s t} dt$ with quiescent initial conditions:
$$\tau_\Delta s \bar{\theta}(x, s) + \frac{d\bar{q}}{dx} = 0 \implies \frac{d\bar{q}}{dx} = -\tau_\Delta s \bar{\theta}(x, s) \tag{14}$$
$$(1 + \tau_q s)\bar{q}(x, s) + \tau_\Delta \frac{d\bar{\theta}}{dx} - \kappa^2 \frac{d^2\bar{q}}{dx^2} = 0 \tag{15}$$

### 4.1 Derivation of the Temperature Helmholtz Equation
Differentiating Eq. (15) with respect to $x$:
$$(1 + \tau_q s)\frac{d\bar{q}}{dx} + \tau_\Delta \frac{d^2\bar{\theta}}{dx^2} - \kappa^2 \frac{d^3\bar{q}}{dx^3} = 0$$
Substituting Eq. (14) for $d\bar{q}/dx$ and its second spatial derivative $d^3\bar{q}/dx^3 = -\tau_\Delta s \frac{d^2\bar{\theta}}{dx^2}$:
$$-(1 + \tau_q s)\tau_\Delta s \bar{\theta} + \tau_\Delta \frac{d^2\bar{\theta}}{dx^2} + \kappa^2 \tau_\Delta s \frac{d^2\bar{\theta}}{dx^2} = 0$$
Dividing by $\tau_\Delta$:
$$(1 + \kappa^2 s)\frac{d^2\bar{\theta}}{dx^2} - s(1 + \tau_q s)\bar{\theta} = 0$$
Assuming $\operatorname{Re}(s) > 0$ such that $1 + \kappa^2 s \ne 0$:
$$\frac{d^2\bar{\theta}}{dx^2} - m^2(s)\bar{\theta} = 0 \tag{16}$$
where the bulk propagation factor $m(s)$ is:
$$m(s) \equiv \sqrt{\frac{s(1 + \tau_q s)}{1 + \kappa^2 s}} \tag{17}$$

---

### 4.2 Derivation of the Heat Flux Helmholtz Equation
Conversely, differentiating Eq. (14) with respect to $x$:
$$\tau_\Delta s \frac{d\bar{\theta}}{dx} + \frac{d^2\bar{q}}{dx^2} = 0 \implies \tau_\Delta \frac{d\bar{\theta}}{dx} = -\frac{1}{s}\frac{d^2\bar{q}}{dx^2}$$
Substituting this expression into Eq. (15):
$$(1 + \tau_q s)\bar{q} - \frac{1}{s}\frac{d^2\bar{q}}{dx^2} - \kappa^2 \frac{d^2\bar{q}}{dx^2} = 0$$
$$\left(\frac{1 + \kappa^2 s}{s}\right)\frac{d^2\bar{q}}{dx^2} - (1 + \tau_q s)\bar{q} = 0$$
Multiplying by $s / (1 + \kappa^2 s)$:
$$\frac{d^2\bar{q}}{dx^2} - m^2(s)\bar{q} = 0 \tag{18}$$
Thus, both temperature $\bar{\theta}$ and heat flux $\bar{q}$ satisfy identical second-order spatial Helmholtz equations governed by the exact same characteristic parameter $m^2(s)$.

---

### 4.3 Rigorous Proof of Modal Completeness (Absence of Missing Flux Modes)
Because the original GK flux equation (15) contains the second derivative $d^2\bar{q}/dx^2$, one must rigorously establish whether an additional boundary condition or homogeneous flux mode is required to close the system.

Let the general solution of the Helmholtz equation (16) for temperature be expressed as:
$$\bar{\theta}(x, s) = C_1 \cosh(m x) + C_2 \sinh(m x) \tag{19}$$
From Eq. (14), integrating $d\bar{q}/dx = -\tau_\Delta s \bar{\theta}$ with respect to $x$:
$$\bar{q}(x, s) = -\frac{\tau_\Delta s}{m} [C_1 \sinh(m x) + C_2 \cosh(m x)] + C_3 \tag{20}$$
where $C_3(s)$ is an arbitrary constant of integration.

Now, we substitute expressions (19) and (20) back into the governing constitutive equation (15):
$$(1 + \tau_q s)\left\{ -\frac{\tau_\Delta s}{m} [C_1 \sinh(m x) + C_2 \cosh(m x)] + C_3 \right\} + \tau_\Delta m [C_1 \sinh(m x) + C_2 \cosh(m x)] - \kappa^2 \left\{ -\tau_\Delta s m [C_1 \sinh(m x) + C_2 \cosh(m x)] \right\} = 0$$
Factoring out $\tau_\Delta [C_1 \sinh(m x) + C_2 \cosh(m x)]$:
$$\tau_\Delta [C_1 \sinh(m x) + C_2 \cosh(m x)] \left\{ -\frac{s(1 + \tau_q s)}{m} + m + \kappa^2 s m \right\} + (1 + \tau_q s)C_3 = 0$$
Evaluating the bracketed term using $m^2 = \frac{s(1 + \tau_q s)}{1 + \kappa^2 s}$:
$$-\frac{s(1 + \tau_q s)}{m} + m(1 + \kappa^2 s) = \frac{-s(1 + \tau_q s) + m^2(1 + \kappa^2 s)}{m} = \frac{-s(1 + \tau_q s) + s(1 + \tau_q s)}{m} \equiv 0.$$
Therefore, the constitutive equation collapses strictly to:
$$(1 + \tau_q s) C_3(s) \equiv 0 \quad \forall x \in [0, 1].$$
For all complex frequencies in the right half-plane $\operatorname{Re}(s) > -1/\tau_q$, the factor $(1 + \tau_q s) \ne 0$. Consequently:
$$C_3(s) \equiv 0 \tag{21}$$
identically.

**Conclusion:** The solution space of the coupled system $(\bar{\theta}, \bar{q})$ possesses **exactly two** degrees of freedom ($C_1, C_2$). There are no missing homogeneous flux modes. Furthermore, the heat flux is uniquely and everywhere related to the temperature gradient by:
$$\bar{q}(x, s) = -\frac{\tau_\Delta s}{m^2(s)} \frac{d\bar{\theta}}{dx} = -\tau_\Delta \left[ \frac{1 + \kappa^2 s}{1 + \tau_q s} \right] \frac{d\bar{\theta}}{dx} = -\tau_\Delta \mu(s) \frac{d\bar{\theta}}{dx} \tag{22}$$
where the dynamic mobility operator is:
$$\mu(s) \equiv \frac{1 + \kappa^2 s}{1 + \tau_q s} \tag{23}$$
In dimensional variables, this corresponds to the effective Laplace thermal conductivity:
$$\lambda_{\mathrm{eff}}(s) = \lambda_0 \left[ \frac{1 + \left(\frac{\kappa^2}{\alpha_0}\right)s}{1 + \tau_q s} \right] \tag{24}$$
The two physical Robin boundary conditions at $x = 0$ and $x = 1$ completely, uniquely, and rigorously close the boundary-value problem without requiring ad-hoc boundary conditions on $q$.

---

## 5. Closed-Form Asymmetric Robin Transfer Function

We now solve the boundary-value problem for arbitrary, unequal Biot numbers $Bi_0 \ne Bi_L$.

Represent $\bar{\theta}(x, s)$ in the coordinate centered at the rear face:
$$\bar{\theta}(x, s) = A \cosh(m(1 - x)) + B \sinh(m(1 - x)) \tag{25}$$
From Eq. (22), the heat flux is:
$$\bar{q}(x, s) = -\tau_\Delta \mu(s) \frac{d\bar{\theta}}{dx} = \tau_\Delta m \mu [A \sinh(m(1 - x)) + B \cosh(m(1 - x))] \tag{26}$$

### 5.1 Enforcing the Rear Boundary Condition ($x = 1$)
From Eq. (13b):
$$\bar{q}(1, s) = \tau_\Delta Bi_L \bar{\theta}(1, s)$$
Evaluating Eqs. (25) and (26) at $x = 1$:
$$\bar{\theta}(1, s) = A, \qquad \bar{q}(1, s) = \tau_\Delta m \mu B$$
$$\tau_\Delta m \mu B = \tau_\Delta Bi_L A \implies B = \frac{Bi_L}{m \mu} A$$
Let $A = C \cdot (m \mu)$, then $B = C \cdot Bi_L$, where $C(s)$ is an overall amplitude factor:
$$\bar{\theta}(x, s) = C(s) [m \mu \cosh(m(1 - x)) + Bi_L \sinh(m(1 - x))] \tag{27}$$
$$\bar{q}(x, s) = \tau_\Delta m \mu C(s) [m \mu \sinh(m(1 - x)) + Bi_L \cosh(m(1 - x))] \tag{28}$$

### 5.2 Enforcing the Front Boundary Condition ($x = 0$)
From Eq. (13a):
$$\bar{q}(0, s) + \tau_\Delta Bi_0 \bar{\theta}(0, s) = \bar{q}_{\mathrm{pulse}}(s)$$
Evaluating at $x = 0$:
$$\bar{\theta}(0, s) = C(s) [m \mu \cosh(m) + Bi_L \sinh(m)]$$
$$\bar{q}(0, s) = \tau_\Delta m \mu C(s) [m \mu \sinh(m) + Bi_L \cosh(m)]$$
Adding $\bar{q}(0, s) + \tau_\Delta Bi_0 \bar{\theta}(0, s)$:
$$\tau_\Delta C(s) \left\{ m \mu [m \mu \sinh(m) + Bi_L \cosh(m)] + Bi_0 [m \mu \cosh(m) + Bi_L \sinh(m)] \right\} = \bar{q}_{\mathrm{pulse}}(s)$$
Expanding and grouping terms:
$$\tau_\Delta C(s) \left\{ [(m \mu)^2 + Bi_0 Bi_L]\sinh(m) + m \mu (Bi_0 + Bi_L)\cosh(m) \right\} = \bar{q}_{\mathrm{pulse}}(s)$$
Define the characteristic denominator determinant:
$$\Delta(s) \equiv [(m \mu)^2 + Bi_0 Bi_L]\sinh(m) + m \mu (Bi_0 + Bi_L)\cosh(m) \tag{29}$$
Then:
$$C(s) = \frac{\bar{q}_{\mathrm{pulse}}(s)}{\tau_\Delta \Delta(s)} \tag{30}$$

### 5.3 Complete Analytical Field and Surface Solutions
Substituting $C(s)$ into Eq. (27) yields the exact closed-form transfer function for arbitrary interior station $x \in [0, 1]$:
$$\bar{\theta}(x, s) = \frac{\bar{q}_{\mathrm{pulse}}(s)}{\tau_\Delta \Delta(s)} [m(s)\mu(s) \cosh(m(s)(1 - x)) + Bi_L \sinh(m(s)(1 - x))] \tag{31}$$

Evaluating at the front and rear faces:
$$\bar{\theta}(0, s) = \frac{\bar{q}_{\mathrm{pulse}}(s)}{\tau_\Delta \Delta(s)} [m(s)\mu(s) \cosh(m(s)) + Bi_L \sinh(m(s))] \tag{32a}$$
$$\bar{\theta}(1, s) = \frac{m(s)\mu(s)}{\tau_\Delta \Delta(s)} \bar{q}_{\mathrm{pulse}}(s) \tag{32b}$$
This holds for arbitrary $Bi_0, Bi_L \ge 0$.

---

## 6. Proof of Theorem 1 (Heat-Loss Invariance at Fourier Resonance)

Define the Guyer–Krumhansl resonance ratio:
$$B \equiv \frac{\kappa^2}{\alpha_0 \tau_q}$$
In our dimensionless system where diffusivity is normalized to $\alpha_0 = 1$, the resonance condition is $B = 1 \iff \kappa^2 = \tau_q$.

**Theorem 1 (Heat-Loss Invariance of Fourier Resonance).**  
*For the linear 1D Guyer–Krumhansl model with constant bulk material properties in a finite slab $x \in [0, 1]$, subject to linear Robin convective and radiative boundary conditions with arbitrary non-negative Biot numbers $Bi_0, Bi_L \ge 0$, quiescent initial conditions, and an admissible laser pulse excitation $q_{\mathrm{pulse}}(t)$, if the Fourier-resonance condition $B = 1$ holds, then the Laplace-domain and time-domain temperature fields coincide identically with that of the corresponding classical Fourier heat conduction problem with the same boundary conditions and excitation:*
$$\left. \theta_{\mathrm{GK}}(x, t; \tau_q, \kappa^2, Bi_0, Bi_L) \right|_{B=1} \equiv \theta_{\mathrm{Fourier}}(x, t; Bi_0, Bi_L) \quad \forall t \ge 0, \; \forall x \in [0, 1]. \tag{33}$$

*Proof.*  
At $B = 1$, we have $\kappa^2 = \tau_q$. Substituting this identity into the dynamic mobility $\mu(s)$ in Eq. (23):
$$\mu(s)\big|_{B=1} = \frac{1 + \tau_q s}{1 + \tau_q s} \equiv 1 \implies \lambda_{\mathrm{eff}}(s) \equiv \lambda_0 \tag{34}$$
Substituting $\kappa^2 = \tau_q$ into the bulk propagation parameter $m(s)$ in Eq. (17):
$$m^2(s)\big|_{B=1} = \frac{s(1 + \tau_q s)}{1 + \tau_q s} \equiv s \implies m(s)\big|_{B=1} \equiv \sqrt{s} \tag{35}$$
Consequently:
$$(m \mu)\big|_{B=1} = \sqrt{s} \cdot 1 = \sqrt{s} \tag{36}$$
The characteristic denominator (29) reduces identically to:
$$\Delta(s)\big|_{B=1} = [s + Bi_0 Bi_L]\sinh(\sqrt{s}) + \sqrt{s}(Bi_0 + Bi_L)\cosh(\sqrt{s}) \equiv \Delta_{\mathrm{Fourier}}(s) \tag{37}$$
and the full-field transfer function (31) reduces to:
$$\bar{\theta}(x, s)\big|_{B=1} = \frac{\bar{q}_{\mathrm{pulse}}(s)}{\tau_\Delta \Delta_{\mathrm{Fourier}}(s)} [\sqrt{s}\cosh(\sqrt{s}(1 - x)) + Bi_L \sinh(\sqrt{s}(1 - x))] \equiv \bar{\theta}_{\mathrm{Fourier}}(x, s; Bi_0, Bi_L) \tag{38}$$
Because both the bulk differential operator ($m(s) \to \sqrt{s}$) and the dynamic surface impedance operator ($\lambda_{\mathrm{eff}}(s) \to \lambda_0$) lose all dependence on $\tau_q$ and $\kappa^2$ simultaneously, the full two-point boundary-value problem is formally identical to classical Fourier heat conduction with surface convection $Bi_0, Bi_L$.

Since this linear two-point boundary-value problem has a unique solution in the Laplace domain for all $s \in \mathbb{C}$ with $\operatorname{Re}(s) > 0$, taking the inverse Laplace transform establishes Eq. (33) identically for all $t \ge 0$ and all $x \in [0, 1]$. $\blacksquare$

---

## 7. Chain-Rule Sensitivity Theorem & Identifiability Classifications

We now provide a rigorous mathematical derivation of the sensitivity collinearity from the parameterized forward model, addressing the critical distinction between directional derivatives along a manifold and individual partial derivatives.

### 7.1 Identifiability Classifications
1. **Structural Global Identifiability:** A parameter vector $\bm{\theta} \in \Theta$ is structurally globally identifiable if the mapping $\bm{\theta} \mapsto \theta(x, t; \bm{\theta})$ is injective. Because $\theta(x, t; \tau_q, \alpha_0 \tau_q) \equiv \theta_{\mathrm{Fourier}}(x, t)$ is invariant for all $\tau_q > 0$, the parameter pair $(\tau_q, \kappa^2)$ is globally structurally non-identifiable on the resonance manifold $\mathcal{M} = \{(\tau_q, \kappa^2) : \kappa^2 = \alpha_0 \tau_q\}$.
2. **Local Structural Identifiability:** A parameter vector is locally structurally identifiable if the sensitivity Jacobian $\bm{J} = \nabla_{\bm{\theta}} \theta$ has full column rank. If $\operatorname{rank}(\bm{J}) < p$, the parameter vector is locally structurally non-identifiable.
3. **Practical Identifiability:** Even when a model is structurally identifiable ($B \ne 1$), parameters may be practically non-identifiable due to finite sampling, limited observation time, and experimental measurement noise covariance $\bm{W}$.

### 7.2 Rigorous Derivation of Individual Partial Derivatives
The forward temperature field $\bar{\theta}(x, s; \tau_q, \kappa^2)$ depends on $\tau_q$ and $\kappa^2$ exclusively through the two intermediate scalar functions $u(s) \equiv m(s)$ and $v(s) \equiv m(s)\mu(s) = s / m(s)$.
By the multivariate chain rule:
$$\frac{\partial \bar{\theta}}{\partial \tau_q} = \frac{\partial \bar{\theta}}{\partial u} \frac{\partial m}{\partial \tau_q} + \frac{\partial \bar{\theta}}{\partial v} \frac{\partial (m\mu)}{\partial \tau_q} \tag{39}$$
$$\frac{\partial \bar{\theta}}{\partial \kappa^2} = \frac{\partial \bar{\theta}}{\partial u} \frac{\partial m}{\partial \kappa^2} + \frac{\partial \bar{\theta}}{\partial v} \frac{\partial (m\mu)}{\partial \kappa^2} \tag{40}$$

Let us compute the derivatives of $m$ and $m\mu$ with respect to $\tau_q$ and $\kappa^2$ at the resonance condition $\kappa^2 = \tau_q$ (in dimensionless variables where $\alpha_0 = 1$):
$$m(s) = \sqrt{s} \left(\frac{1 + \tau_q s}{1 + \kappa^2 s}\right)^{1/2}$$
$$\left. \frac{\partial m}{\partial \tau_q} \right|_{\kappa^2 = \tau_q} = \sqrt{s} \cdot \frac{1}{2}\left(\frac{1 + \tau_q s}{1 + \tau_q s}\right)^{-1/2} \frac{s}{1 + \tau_q s} = \frac{s^{3/2}}{2(1 + \tau_q s)} \tag{41}$$
$$\left. \frac{\partial m}{\partial \kappa^2} \right|_{\kappa^2 = \tau_q} = \sqrt{s} \cdot \frac{1}{2}\left(\frac{1 + \tau_q s}{1 + \tau_q s}\right)^{-1/2} \left[ -\frac{s(1 + \tau_q s)}{(1 + \tau_q s)^2} \right] = -\frac{s^{3/2}}{2(1 + \tau_q s)} \tag{42}$$
Hence:
$$\left. \frac{\partial m}{\partial \tau_q} \right|_{B=1} = -\left. \frac{\partial m}{\partial \kappa^2} \right|_{B=1} \tag{43}$$

Similarly, for $v(s) = m(s)\mu(s) = \sqrt{s} \left(\frac{1 + \kappa^2 s}{1 + \tau_q s}\right)^{1/2}$:
$$\left. \frac{\partial (m\mu)}{\partial \tau_q} \right|_{\kappa^2 = \tau_q} = -\frac{s^{3/2}}{2(1 + \tau_q s)} \tag{44}$$
$$\left. \frac{\partial (m\mu)}{\partial \kappa^2} \right|_{\kappa^2 = \tau_q} = +\frac{s^{3/2}}{2(1 + \tau_q s)} \tag{45}$$
Hence:
$$\left. \frac{\partial (m\mu)}{\partial \tau_q} \right|_{B=1} = -\left. \frac{\partial (m\mu)}{\partial \kappa^2} \right|_{B=1} \tag{46}$$

Substituting Eqs. (43) and (46) into Eq. (40):
$$\left. \frac{\partial \bar{\theta}}{\partial \kappa^2} \right|_{B=1} = \frac{\partial \bar{\theta}}{\partial u} \left(-\left.\frac{\partial m}{\partial \tau_q}\right|_{B=1}\right) + \frac{\partial \bar{\theta}}{\partial v} \left(-\left.\frac{\partial (m\mu)}{\partial \tau_q}\right|_{B=1}\right) = -\left. \frac{\partial \bar{\theta}}{\partial \tau_q} \right|_{B=1} \tag{47}$$
In dimensional variables, scaling yields:
$$J_{\tau_q}(t) = -\alpha_0 J_{\kappa^2}(t) \quad \forall t \ge 0, \; \forall x \in [0, 1] \tag{48}$$

**Significance:**
- $J_{\tau_q}(t) = \frac{\partial \theta}{\partial \tau_q}$ and $J_{\kappa^2}(t) = \frac{\partial \theta}{\partial \kappa^2}$ are **individually non-zero, time-varying sensitivity signals**.
- They are not identically zero; rather, they are **strictly anti-collinear**.
- Equation (48) holds from direct differentiation of the forward model, confirming that the sensitivity collinearity is an exact structural property of the boundary-value problem and not merely an informal directional derivative argument.

---

## 8. Fisher Information Matrix, SVD, and Statistical Noise Formulation

In inverse parameter estimation, let observations $\bm{y} \in \mathbb{R}^N$ be collected at discrete times $t_1, \dots, t_N$:
$$\bm{y} = \bm{\theta}_{\mathrm{model}}(\bm{p}) + \bm{\epsilon}, \qquad \bm{\epsilon} \sim \mathcal{N}(\bm{0}, \bm{\Sigma})$$
where $\bm{\Sigma} = \sigma_n^2 \bm{I}_N$ is the measurement-noise covariance under independent and identically distributed (i.i.d.) Gaussian noise.

The weighted Fisher Information Matrix (FIM) is defined by:
$$\bm{F} = \bm{J}^\top \bm{W} \bm{J} = \frac{1}{\sigma_n^2} \bm{J}^\top \bm{J} \tag{49}$$
where $\bm{W} = \bm{\Sigma}^{-1}$ is the inverse noise weighting matrix.

### 8.1 Three-Parameter System $(\tau_q, \kappa^2, Bi)$
Consider simultaneous estimation of $\bm{p} = (\tau_q, \kappa^2, Bi)^\top$. The sensitivity Jacobian is:
$$\bm{J} = \begin{bmatrix} \bm{J}_{\tau_q} & \bm{J}_{\kappa^2} & \bm{J}_{Bi} \end{bmatrix} \in \mathbb{R}^{N \times 3}$$
At Fourier resonance $B = 1$, substituting $\bm{J}_{\kappa^2} = -\frac{1}{\alpha_0}\bm{J}_{\tau_q}$:
$$\bm{J} = \begin{bmatrix} \bm{J}_{\tau_q} & -\frac{1}{\alpha_0}\bm{J}_{\tau_q} & \bm{J}_{Bi} \end{bmatrix}$$
The null vector of $\bm{J}$ is, for the **dimensional** parameter set
$\bm{p} = (\tau_q, \kappa^2, Bi)^\top$:
$$\bm{v}_{\mathrm{null}} = \begin{pmatrix} 1 \\ \alpha_0 \\ 0 \end{pmatrix}$$
since, using $\bm{J}_{\kappa^2} = -\alpha_0^{-1}\bm{J}_{\tau_q}$:
$$\bm{J} \bm{v}_{\mathrm{null}} = 1 \cdot \bm{J}_{\tau_q} + \alpha_0 \left(-\frac{1}{\alpha_0}\bm{J}_{\tau_q}\right) + 0 \cdot \bm{J}_{Bi} = \bm{0} \tag{50}$$
If instead both non-Fourier parameters are scaled by $\alpha_0$ (the **dimensionless**
parameter set used for the numerical singular-value spectra), the same geometric direction is
$$\bm{v}_{\mathrm{null}} = \begin{pmatrix} 1 \\ 1 \\ 0 \end{pmatrix}.$$
The two forms are the same null direction expressed in different coordinates and are used
consistently in the manuscript, the code, and the figure captions.

### 8.2 Separation of Structural Rank Deficiency from Numerical Singular Floor
- **Structural Mathematics:** The true physical Fisher Information Matrix possesses eigenvalues $\lambda_1 > 0$, $\lambda_2 > 0$, and $\lambda_3 \equiv 0$. The exact mathematical rank is $\operatorname{rank}(\bm{F}) = 2 < 3$, and $\operatorname{cond}(\bm{F}) = \infty$.
- **Numerical Approximation:** In floating-point arithmetic with central finite-difference perturbations ($h \sim 10^{-4}$ to $10^{-6}$), truncation errors induce an apparent singular value $\sigma_3 \approx 7 \times 10^{-8}$ (and up to $2.7 \times 10^{-5}$ at the steepest point of the transient). In the analytic-differentiation channel the computed value is zero to below double-precision unit roundoff. Any such finite value is an artifact of the evaluation channel, NOT an eigenvalue of the underlying physics.
- **Biot Number Identifiability:** Because $\bm{v}_{\mathrm{null}}$ has strictly zero component along the $Bi$ axis ($v_{\mathrm{null}, 3} = 0$), boundary heat loss forms an orthogonal observable subspace ($\sigma_2 \approx 5.35 - 13.57$) with condition ratio $\sigma_1 / \sigma_2 \in [2.34, 4.90]$. Thus, $Bi$ is cleanly identifiable from the cooling tail, while the internal degeneracy between $\tau_q$ and $\kappa^2$ remains completely unregularized.

---

## 9. Near-Resonance Asymptotic Scaling & Practical Identifiability Corridor

To quantify the neighborhood of resonance, let $\delta \equiv B - 1$, so that $\kappa^2 = (1 + \delta)\alpha_0 \tau_q$.

### 9.1 Asymptotic Taylor Expansion
Expanding the mobility operator for small $|\delta| \ll 1$:
$$\mu(s) = \frac{1 + (1 + \delta)\tau_q s}{1 + \tau_q s} = 1 + \delta \left(\frac{\tau_q s}{1 + \tau_q s}\right) + O(\delta^2)$$
$$m(s) = \sqrt{s} \left[ 1 - \frac{\delta}{2} \left(\frac{\tau_q s}{1 + \tau_q s}\right) + O(\delta^2) \right]$$
The forward temperature field expands as:
$$\theta(t; \tau_q, B) = \theta_{\mathrm{Fourier}}(t) + \delta \, \theta_1(t; \tau_q) + O(\delta^2)$$
The sensitivity vectors satisfy:
$$J_{\kappa^2} = \frac{1}{\tau_q} \frac{\partial \theta}{\partial B} = \frac{1}{\tau_q} \theta_1(t) + O(\delta)$$
$$J_{\tau_q} = -\frac{1}{\tau_q} \theta_1(t) + \delta \, \psi(t) + O(\delta^2)$$
Consequently, the sensitivity residual is strictly linear in $\delta$:
$$J_{\tau_q}(t) + \alpha_0 J_{\kappa^2}(t) = \delta \, \psi(t) + O(\delta^2) = O(|B - 1|) \tag{51}$$

### 9.2 Singular Value and Condition Number Scaling
The smallest singular value of the three-parameter sensitivity Jacobian
$[J_{\tau_q}, J_{\kappa^2}, J_{Bi}]$ scales as:
$$\sigma_3(B) = C(Bi) |B - 1|^{1.0} \tag{52}$$
where the mean prefactor $C(Bi) \in [1.348, 1.464]$ across $Bi \in [0, 0.5]$ (3-parameter
Jacobian). Regressing the two-parameter subsystem $[J_{\tau_q}, J_{\kappa^2}]$ instead gives
$C(Bi) \in [1.384, 1.482]$, i.e. the two definitions of $\sigma_{\min}$ agree to within
2%; both are archived in `data/scaling_regression_twosided.csv`.
The three-parameter Fisher condition number scales quadratically:
$$\operatorname{cond}(F_{3\times 3}) = \left(\frac{\sigma_1}{\sigma_3}\right)^2 \approx \frac{C'(Bi)}{|B - 1|^2} \tag{53}$$
with $C'(Bi) \in [9.44, 16.30]$ (3-parameter; the 2-parameter values $8.69$--$14.42$ are
archived alongside).

### 9.3 Noise-Induced Practical Non-Identifiability Corridor
Under additive Gaussian noise with standard deviation $\sigma_n$, the Cramér–Rao lower bound for the standard error of parameter estimation along the weakest eigenvector is:
$$\mathrm{SE}(\hat{\theta}_{\mathrm{weak}}) \ge \frac{\sigma_n}{\sigma_{\min}} \approx \frac{\sigma_n}{C(Bi) |B - 1|}$$
Demanding that the relative standard error be bounded by a specified tolerance $\eta$ (e.g., $\eta = 0.10$ for $10\%$ precision) yields the practical non-identifiability corridor:
$$|B - 1|_{\mathrm{crit}} \approx \frac{\sigma_n}{\eta \, C(Bi) \, \tau_{q, 0}} \tag{54}$$
Evaluating Eq.~(54) with the mean prefactor gives the correct order of magnitude, but the
corridors quoted in the manuscript are obtained from the **full three-parameter Fisher
matrix** (Eq.~(50) of the manuscript, $\bm{F} = \sigma_n^{-2}\bm{J}^\top\bm{J}$ with
$\bm{J} = [\bm{J}_{\tau_q}, \bm{J}_{\kappa^2}, \bm{J}_{Bi}]$), because
$\operatorname{SE}(\hat\tau_q)$ involves the whole pseudoinverse and not only
$\sigma_3^{-1}$. The audited values (54-row audit, `data/crlb_configuration_audit.csv`,
Supplementary Table S5) are:

| Configuration | $N_t$ | $\sigma_n = 0.1\%$ | $\sigma_n = 0.5\%$ | $\sigma_n = 1.0\%$ |
|:---|:---:|:---:|:---:|:---:|
| Rear-face only ($x=1.0$) | 10 | 0.246 | 1.228 | 2.455 |
| Rear-face only ($x=1.0$) | 50 | 0.092 | 0.459 | 0.917 |
| Rear-face only ($x=1.0$) | 100 | 0.065 | 0.323 | 0.645 |
| Front + rear ($x=0,1$) | 50 | 0.015 | 0.075 | 0.151 |
| Multi-location (5 stations) | 50 | 0.013 | 0.063 | 0.126 |

(the "Singular" criterion, which uses $\sigma_3$ directly, gives systematically wider
corridors, e.g. 0.130 / 0.648 / 1.296 for rear-face sampling with $N_t = 50$.)

**Physical Conclusion:** Standard laser flash metrology cannot reliably distinguish $\tau_q$
and $\kappa^2$ for any material within the band $|B - 1| \le 0.092$ under $0.1\%$ noise
(rear-face sampling, $N_t = 50$), and within $|B - 1| \le 0.917$ under $1.0\%$ noise.
Boundary heat loss does not narrow this corridor: $Bi$ is orthogonal to the null direction,
so adding cooling information enlarges the observable subspace without touching the
degeneracy.

**Implications and future work:** within the linear model studied here, removing the
degeneracy requires operating away from $B = 1$. Candidate routes -- size-dependent
nonlocality, temperature-dependent or otherwise non-linear constitutive laws, or independent
bulk measurements -- would each change the model structure and therefore require a separate
identifiability analysis; they are noted as directions for future work rather than as results
of the present study.
