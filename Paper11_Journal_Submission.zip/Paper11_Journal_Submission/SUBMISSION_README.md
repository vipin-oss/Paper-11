# Submission contents

**Title:** Invariance of the Guyer-Krumhansl Fourier-Resonance Sensitivity Singularity to Boundary Heat Loss in Laser Flash Testing

**Author:** Dr. Vipin Gupta, Department of Mathematics, Gurugram University, Gurugram, Haryana 122018, India

## Files

| Path | Content |
| --- | --- |
| `manuscript/main.tex` | LaTeX source of the manuscript (single canonical version) |
| `manuscript/main.pdf` | Compiled manuscript, 47 pages, 64 references |
| `manuscript/references.bib` | BibTeX bibliography |
| `manuscript/main.bbl` | Pre-compiled bibliography (allows a pdflatex-only build) |
| `manuscript/elsarticle.cls`, `manuscript/elsarticle-num.bst` | Elsevier class and bibliography style, bundled |
| `manuscript/compile.sh` | Build script (requires pdflatex and bibtex) |
| `manuscript/figures/` | The 10 publication figures as vector PDF and 300-DPI PNG |
| `supplementary/supplementary_material.tex` | Supplementary material, Tables S1-S6 |
| `supplementary/supplementary_material.pdf` | Compiled supplementary material, 6 pages |

## Compilation

```bash
cd manuscript && bash compile.sh      # pdflatex, bibtex, pdflatex, pdflatex
cd ../supplementary && pdflatex supplementary_material.tex && pdflatex supplementary_material.tex
```

The supplementary tables are generated directly from the archived datasets by `program/make_supplementary.py`, supplied in the reproducibility package that accompanies this submission.
